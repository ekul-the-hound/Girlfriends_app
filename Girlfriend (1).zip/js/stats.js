/* ============================================================
   stats.js — relationship stats
   ============================================================ */

const Stats = {
  render() {
    const el = document.getElementById("stats");
    const start = DB.get("relStart", RELATIONSHIP_START);
    const days = daysBetween(start, Date.now());
    const msgs = DB.get("messages", []).length;
    const diary = DB.get("diary", []).length;
    const games = DB.get("activity", []).filter((a) => /won|played|Memory|checkers|Rather/i.test(a.text)).length;
    const pet = Pet.data();
    const photos = DB.get("photos", []).length;

    el.innerHTML = `
      ${UI.topbar("Relationship Stats", "💖 Luke & Sophie, by the numbers")}
      <div class="stat-card rose">
        <span class="ic">💖</span>
        <div class="big" id="statDays">0</div>
        <div class="lbl">days Luke &amp; Sophie have loved each other</div>
      </div>
      <div class="row" style="gap:12px">
        <div class="stat-card lav grow"><span class="ic">💌</span><div class="big">${msgs}</div><div class="lbl">love letters sent</div></div>
        <div class="stat-card sage grow"><span class="ic">📖</span><div class="big">${diary}</div><div class="lbl">diary chapters</div></div>
      </div>
      <div class="row" style="gap:12px">
        <div class="stat-card lav grow"><span class="ic">🎮</span><div class="big">${games}</div><div class="lbl">game nights</div></div>
        <div class="stat-card rose grow"><span class="ic">🖼️</span><div class="big">${photos}</div><div class="lbl">photos saved</div></div>
      </div>
      <div class="stat-card sage">
        <span class="ic">🐶</span>
        <div class="big">${Math.round(pet.happiness)}%</div>
        <div class="lbl">${UI.esc(pet.name)} is this happy!</div>
      </div>

      <div class="section-label">Mood trends 📈 (last 14 days)</div>
      <div class="card">${this.moodChart()}</div>

      <div class="center muted mt" style="font-size:12px">Together since ${fmtDate(new Date(start).getTime())}</div>`;

    // count-up animation
    this.countUp(document.getElementById("statDays"), days);
  },

  countUp(el, target) {
    if (!el) return;
    let v = 0; const step = Math.max(1, Math.ceil(target / 40));
    const t = setInterval(() => {
      v += step; if (v >= target) { v = target; clearInterval(t); }
      el.textContent = v;
    }, 24);
  },

  moodChart() {
    const hist = DB.get("moodHistory", []);
    // positivity score per day
    const positive = ["Happy","Amazing","Adoring","Romantic","Grateful","Cuddly","Playful","Energetic","Celebrate","Optimistic","Peaceful","Content","Chill","Inspired","Confident","Excited","Relaxed"];
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const dk = todayKey(new Date(Date.now() - i * 86400000));
      const dayMoods = hist.filter((h) => todayKey(new Date(h.ts)) === dk);
      let score = 0.15;
      if (dayMoods.length) {
        const pos = dayMoods.filter((h) => positive.includes(h.mood)).length;
        score = pos / dayMoods.length;
      }
      days.push(score);
    }
    if (!hist.length) return UI.empty("📈", "Pick moods on the home screen to see trends!");
    return `<div class="chart">${days.map((s) => `<div class="bar" style="height:${10 + s * 100}%"></div>`).join("")}</div>
      <div class="center muted" style="font-size:11px">happier days reach higher 💗</div>`;
  },
};
