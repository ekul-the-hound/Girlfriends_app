/* ============================================================
   questions.js — daily questions (answers hidden until both submit)
   ============================================================ */

const QUESTIONS = [
  "What's one thing Luke did recently that made you smile?",
  "Sophie, what's a dream you have for your future with Luke?",
  "If we could teleport anywhere right now, where would we go?",
  "What's your favorite memory of us so far?",
  "What song reminds you of us?",
  "What's one little habit of mine you secretly love?",
  "If we had a whole day together tomorrow, how would we spend it?",
  "What made you fall for me?",
  "Luke, what's something about Sophie you're proud of?",
  "What's a tiny thing that would make your day better right now?",
  "What's the first thing you want to do when we're together again?",
  "Describe me in three words.",
  "What's a fear you've never told me?",
  "What's our 'thing' — something that's just ours?",
  "What does home feel like to you?",
  "If we wrote a book together, what would it be about?",
  "What's something you're grateful for today?",
  "What's a goal you'd love us to chase together?",
  "Sophie, what makes you feel most loved by Luke?",
  "Luke, when do you feel closest to Sophie?",
  "What's a food you wish we could share right now?",
  "What's the most romantic thing you can imagine us doing?",
  "What's something silly that always makes you think of me?",
  "Where do you see us in five years?",
  "What's a small win you had today?",
  "What's your love language, and how can I speak it better?",
  "What's a movie we have to watch together?",
  "What's something new you'd like to try as a couple?",
  "What's the best advice about love you've ever heard?",
  "What does a perfect lazy Sunday with me look like?",
  "What's a place from your childhood you want to show me?",
  "What's something I do that makes you feel safe?",
  "If you could relive one moment with me, which one?",
  "What's a tradition you'd like us to start?",
  "What three things are you most thankful for in our relationship?",
  "What's something you want to learn together?",
  "Sophie, what's your favorite thing about Luke's personality?",
  "Luke, what's a moment you knew Sophie was special?",
  "What's a gift you wish you could give me right now?",
  "What's the bravest thing love has made you do?",
  "What do you miss most when we're apart?",
  "What's a smell or taste that reminds you of me?",
  "How has loving me changed you?",
  "What's a question you've always wanted to ask me?",
  "What's our funniest moment together?",
  "What's something you admire about how I handle hard days?",
  "If we adopted a pet today, what would we name it?",
  "What's one promise you want to make to us?",
  "What does forever look like to you?",
  "What's the kindest thing I've ever done for you?",
  "What part of your day do you most wish I was there for?",
  "What's a dream date you've never told me about?",
  "What's a quality of mine you hope our future has more of?",
  "What's a hard thing we got through that made us stronger?",
  "What would you cook for me if I walked in right now?",
  "What's a city you'd love for us to get lost in together?",
  "What's the most 'us' thing about us?",
  "What's something I say that you replay in your head?",
  "What's one way I can support you this week?",
  "What's a season or holiday you can't wait to spend with me?",
  "If today had a soundtrack, what song would be playing for us?",
  "What's something you're looking forward to this month?",
  "What's a photo of us you wish you could frame?",
  "What's a tiny ritual that would make the distance easier?",
  "What's the most you've ever laughed because of me?",
  "What do you hope I know that I might forget on hard days?",
  "What's a future trip you're already daydreaming about?",
  "Sophie, what's something Luke does that feels like home?",
  "Luke, what's a way Sophie makes ordinary days better?",
  "What's a word you'd put on a necklace for us?",
  "What's the bravest dream you have for yourself?",
  "What helps you feel close to me even from far away?",
  "What's a memory you want us to make this year?",
  "What's something you've never said out loud but want me to know?",
  "What's your favorite way I say goodnight?",
  "What's a question you hope we'll answer together someday?",
  "What's the smallest thing that gives you butterflies?",
  "What's a habit you'd love for us to build together?",
  "What would our perfect morning together look like?",
  "What's a way you've grown that you're proud of?",
  "What's a piece of our story you'd tell our grandkids?",
  "If I could appear at your door right now, what would we do first?",
  "What's a comfort show or book you wish we shared?",
  "What's something about long distance that surprised you?",
  "What's a way I can make you feel chosen today?",
  "What do you love about who we are together?",
  "What's a small adventure we could have on our next call?",
  "What's the most thoughtful thing someone could do for you?",
  "What does loving well mean to you?",
  "What's a hope you're praying for us?",
  "What's a memory that always makes you smile when you miss me?",
  "What's something you want to do less of, and how can I help?",
  "What's a future version of us you're excited to meet?",
  "What's the best part of having me in your life?",
  "What's a place you'd marry me in, if you could pick anywhere?",
  "What's a tiny thing I do that you'd miss if it were gone?",
  "What's one word for how I make you feel?",
  "What are you most excited to build with me?",
];

const WEEKLY_Q = [
  "Looking back over this season apart — what's one way we've grown closer, and one thing you want us to keep working on?",
  "If you wrote a letter to us a year from now, what would you want it to say we accomplished together?",
  "What does a thriving, godly relationship look like to you — and where are we already living it out?",
];

const Questions = {
  /* full pool = built-in + your own custom questions */
  custom() { return DB.get("customQuestions", []); },
  all() { return QUESTIONS.concat(this.custom()); },
  q(i) { const a = this.all(); return a[((i % a.length) + a.length) % a.length]; },
  todayIndex() {
    const epoch = Math.floor(Date.now() / 86400000);
    return epoch % this.all().length;
  },
  weekIndex() {
    const week = Math.floor(Date.now() / (7 * 86400000));
    return week % WEEKLY_Q.length;
  },
  state() {
    const key = todayKey();
    let s = DB.get("qState", null);
    if (!s || s.date !== key) {
      s = { date: key, qi: this.todayIndex(), luke: null, sophie: null, saveToDiary: true };
      DB.set("qState", s);
    }
    return s;
  },

  render() {
    const el = document.getElementById("questions");
    const s = this.state();
    const q = this.q(s.qi);
    const mine = s[App.who];
    const both = s.luke && s.sophie;

    let body;
    if (both) {
      body = this.compareView(s, q);
    } else {
      body = `
        <div class="q-card">
          <div class="badge">Question of the day</div>
          <div class="q">${UI.esc(q)}</div>
          ${mine
            ? `<div class="chip sage">✓ ${PEOPLE[App.who].name} answered — waiting for ${PEOPLE[App.who==="luke"?"sophie":"luke"].name} 🫶</div>`
            : `<textarea class="q-answer" id="qAnswer" placeholder="Answer as ${PEOPLE[App.who].name}…"></textarea>
               <button class="btn primary block mt heartbeat" onclick="Questions.submit()">Submit my answer</button>`}
        </div>`;
    }

    el.innerHTML = `
      ${UI.topbar("Daily Questions", "❓ get to know each other, daily")}
      <div class="row between" style="margin-bottom:12px">
        <div class="who-toggle">
          <button class="luke ${App.who==="luke"?"on":""}" onclick="Questions.setWho('luke')">🦂 Luke</button>
          <button class="sophie ${App.who==="sophie"?"on":""}" onclick="Questions.setWho('sophie')">🌸 Sophie</button>
        </div>
        <span class="muted" style="font-size:11px">answering as ${PEOPLE[App.who].name}</span>
      </div>
      ${body}
      <div class="row" style="gap:8px;margin-top:12px">
        <button class="btn ghost grow" onclick="Questions.addOwn()">✍️ Add your own question</button>
        <button class="btn ghost" onclick="Questions.shuffle()">🎲</button>
      </div>
      ${this.customListNote()}
      <div class="section-label">🗓️ Question of the week</div>
      <div class="q-card" style="text-align:left">
        <div class="q" style="font-size:18px">${UI.esc(WEEKLY_Q[this.weekIndex()])}</div>
        <button class="btn ghost block" onclick="Questions.weeklyToDiary()">📖 Answer in our diary</button>
      </div>`;
  },

  compareView(s, q) {
    const match = this.isMatch(s.luke, s.sophie);
    return `<div class="q-card" style="text-align:left">
        <div class="badge">Today's question — both answered! 🎉</div>
        <div class="q" style="font-size:19px">${UI.esc(q)}</div>
      </div>
      ${match ? `<div class="match-banner">❤️ Match! You're on the same page</div>` : ""}
      <div class="answer-compare">
        <div class="a luke"><div class="nm">🦂 Luke</div>${UI.esc(s.luke)}</div>
        <div class="a sophie"><div class="nm">🌸 Sophie</div>${UI.esc(s.sophie)}</div>
      </div>
      <label class="row" style="gap:8px;margin-top:14px;font-size:13px">
        <input type="checkbox" ${s.saveToDiary ? "checked" : ""} onchange="Questions.toggleSave(this.checked)" />
        Save both answers to our diary
      </label>
      <button class="btn ghost block mt" onclick="Questions.nextQuestion()">Skip to another question →</button>`;
  },

  isMatch(a, b) {
    if (!a || !b) return false;
    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, "").split(/\s+/).filter((w) => w.length > 3);
    const A = new Set(norm(a)), B = norm(b);
    if (!B.length) return false;
    const overlap = B.filter((w) => A.has(w)).length;
    return overlap / B.length > 0.4 || a.trim().toLowerCase() === b.trim().toLowerCase();
  },

  submit() {
    const val = document.getElementById("qAnswer").value.trim();
    if (!val) { UI.toast("Type your answer first 💭"); return; }
    const s = this.state();
    s[App.who] = val;
    DB.set("qState", s);
    if (s.luke && s.sophie) {
      Streaks.did("questions");
      Coins.add(4);
      logActivity("💬", "You both answered today's question");
      if (this.isMatch(s.luke, s.sophie)) UI.confetti(50);
      if (s.saveToDiary) this.saveToDiary(s);
    } else {
      logActivity("💬", `${PEOPLE[App.who].name} answered the daily question`);
    }
    UI.floaty("💗");
    this.render();
  },
  toggleSave(v) { const s = this.state(); s.saveToDiary = v; DB.set("qState", s); },
  saveToDiary(s) {
    const list = DB.get("diary", []);
    list.push({
      id: uid(), author: "luke", date: Date.now(),
      title: "Daily Q: " + this.q(s.qi),
      text: `🦂 Luke: ${s.luke}\n\n🌸 Sophie: ${s.sophie}`,
      tags: ["dailyq"], images: [], privateTo: null,
    });
    DB.set("diary", list);
  },
  nextQuestion() {
    const s = this.state();
    s.qi = (s.qi + 1) % this.all().length; s.luke = null; s.sophie = null;
    DB.set("qState", s);
    this.render();
  },
  shuffle() {
    const s = this.state();
    const n = this.all().length;
    let r = s.qi;
    if (n > 1) while (r === s.qi) r = Math.floor(Math.random() * n);
    s.qi = r; s.luke = null; s.sophie = null;
    DB.set("qState", s);
    this.render();
  },

  /* ---------- your own questions ---------- */
  customListNote() {
    const c = this.custom();
    if (!c.length) return "";
    return `<div class="center muted" style="font-size:12px;margin-bottom:6px">
      💞 ${c.length} of your own question${c.length>1?"s":""} are in the mix ·
      <span style="color:var(--lavender-deep);font-weight:700" onclick="Questions.manageOwn()">manage</span></div>`;
  },
  addOwn() {
    UI.modal(`<h3>Add your own question ✍️</h3>
      <div class="field-group"><label>Your question</label>
        <textarea id="newQ" rows="3" placeholder="e.g. Sophie, what made you smile about Luke this week?"></textarea></div>
      <button class="btn primary block" onclick="Questions.saveOwn(false)">Add to the pool</button>
      <button class="btn ghost block mt-s" onclick="Questions.saveOwn(true)">Add &amp; ask it right now</button>`);
  },
  saveOwn(askNow) {
    const v = document.getElementById("newQ").value.trim();
    if (!v) { UI.toast("Type your question first 💭"); return; }
    const c = this.custom();
    c.push(v);
    DB.set("customQuestions", c);
    UI.closeModal();
    if (askNow) {
      const s = this.state();
      s.qi = this.all().length - 1; s.luke = null; s.sophie = null;
      DB.set("qState", s);
    }
    UI.floaty("✍️");
    UI.toast(askNow ? "Asking your question now 💕" : "Added to your questions 💕");
    this.render();
  },
  manageOwn() {
    const c = this.custom();
    UI.modal(`<h3>Your questions ✍️</h3>
      ${c.length ? c.map((q, i) => `<div class="prayer-item">
          <div class="grow"><div class="pt">${UI.esc(q)}</div></div>
          <button class="btn sm ghost" onclick="Questions.delOwn(${i})">✕</button></div>`).join("")
        : UI.empty("✍️", "No custom questions yet")}
      <button class="btn primary block mt" onclick="UI.closeModal();Questions.addOwn()">＋ Add another</button>`);
  },
  delOwn(i) {
    const c = this.custom();
    c.splice(i, 1);
    DB.set("customQuestions", c);
    this.manageOwn();
    this.render();
  },
  weeklyToDiary() {
    Diary.compose();
    setTimeout(() => {
      const t = document.getElementById("dTitle"); const x = document.getElementById("dText");
      if (t) t.value = "Weekly reflection";
      if (x) x.value = WEEKLY_Q[this.weekIndex()] + "\n\n";
    }, 60);
  },
  setWho(w) { App.setWho(w); this.render(); },
};
