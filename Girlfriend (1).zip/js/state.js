/* ============================================================
   state.js — persistence, app state, shared helpers
   Everything lives in localStorage. No backend.
   ============================================================ */

const PEOPLE = {
  luke:   { name: "Luke",   emoji: "🦂", cls: "luke" },
  sophie: { name: "Sophie", emoji: "🌸", cls: "sophie" },
};
const RELATIONSHIP_START = "2024-02-14"; // edit in Settings

/* ---------- tiny storage layer ---------- */
const DB = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem("ourCorner_" + key);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) { return fallback; }
  },
  set(key, val) {
    try { localStorage.setItem("ourCorner_" + key, JSON.stringify(val)); }
    catch (e) { UI.toast("Storage full — try removing old photos 💾"); }
  },
  del(key) { localStorage.removeItem("ourCorner_" + key); },
};

/* ---------- date helpers ---------- */
const todayKey = (d = new Date()) =>
  d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");

function daysBetween(a, b) {
  const ms = Math.abs(new Date(b) - new Date(a));
  return Math.floor(ms / 86400000);
}
function relTime(ts) {
  const diff = (Date.now() - ts) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return Math.floor(diff / 60) + "m ago";
  if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
  if (diff < 172800) return "yesterday";
  return new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function fmtDate(ts) {
  return new Date(ts).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" });
}
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ---------- love coins (earned currency) ---------- */
const Coins = {
  get() { return DB.get("coins", 20); },
  add(n, reason) {
    const v = this.get() + n;
    DB.set("coins", v);
    if (n > 0) UI.floaty("💗", null);
    Pet && Pet.refreshCoins && Pet.refreshCoins();
    return v;
  },
  spend(n) {
    const v = this.get();
    if (v < n) return false;
    DB.set("coins", v - n);
    Pet && Pet.refreshCoins && Pet.refreshCoins();
    return true;
  },
};

/* ---------- activity feed ---------- */
function logActivity(emoji, text) {
  const feed = DB.get("activity", []);
  feed.unshift({ emoji, text, ts: Date.now() });
  DB.set("activity", feed.slice(0, 40));
}

/* ---------- streaks ----------
   keys: bible, pray, photo, questions, draw
   each = { count, last: 'YYYY-MM-DD', history: ['YYYY-MM-DD', ...] }
------------------------------- */
const STREAK_DEFS = [
  { key: "bible",     icon: "📖", name: "Bible Reading" },
  { key: "pray",      icon: "🙏", name: "Praying Together" },
  { key: "photo",     icon: "📸", name: "New Photo Uploaded" },
  { key: "questions", icon: "💬", name: "Daily Questions" },
  { key: "draw",      icon: "🎨", name: "Drew for Each Other" },
];
const Streaks = {
  all() { return DB.get("streaks", {}); },
  one(key) { return this.all()[key] || { count: 0, last: null, history: [] }; },
  did(key) {
    const all = this.all();
    const s = all[key] || { count: 0, last: null, history: [] };
    const today = todayKey();
    if (s.last === today) return s; // already counted today
    const yest = todayKey(new Date(Date.now() - 86400000));
    s.count = s.last === yest ? s.count + 1 : 1;
    s.last = today;
    s.history = [...new Set([...(s.history || []), today])].slice(-90);
    all[key] = s;
    DB.set("streaks", all);
    Coins.add(3);
    return s;
  },
  isDoneToday(key) { return this.one(key).last === todayKey(); },
};

/* ---------- moods catalogue ---------- */
const MOODS = [
  ["😌","Relaxed"],["🌟","Amazing"],["🤩","Excited"],["😊","Happy"],["🙏","Grateful"],
  ["😏","Flirty"],["🤗","Cuddly"],["🥺","Cute"],["😢","Sad"],["😰","Stressed"],
  ["😴","Tired"],["🔥","Fired Up"],["🥳","Celebrate"],["💫","Inspired"],["🌈","Optimistic"],
  ["😎","Confident"],["😘","Romantic"],["🥰","Adoring"],["💞","Passionate"],["😐","Neutral"],
  ["🧘","Peaceful"],["🍃","Chill"],["😤","Frustrated"],["😠","Angry"],["😨","Anxious"],
  ["😵","Overwhelmed"],["😔","Lonely"],["😜","Silly"],["🤪","Goofy"],["😹","Playful"],["🎉","Energetic"],
];
const moodByName = (n) => MOODS.find((m) => m[1] === n);

/* ---------- global app namespace ---------- */
const App = {
  current: "home",
  who: DB.get("activeWho", "luke"), // who's using the app right now
  setWho(w) { this.who = w; DB.set("activeWho", w); },
};

/* seed first-run data */
function seedOnce() {
  if (DB.get("seeded", false)) return;
  // first diary entry
  DB.set("diary", [{
    id: uid(),
    author: "luke",
    date: Date.now(),
    title: "Day 1 of Our Corner",
    text: "Luke & Sophie start their digital love journey 💖\n\nThis little app is our corner of the world — somewhere we can be close even when the miles say otherwise.",
    tags: ["firstcall"],
    images: [],
    privateTo: null,
  }]);
  // sample countdowns
  const soon = (days) => Date.now() + days * 86400000;
  DB.set("countdowns", [
    { id: uid(), title: "Next Video Call", date: soon(1) + 3600000 * 6 },
    { id: uid(), title: "Our Anniversary", date: new Date(new Date().getFullYear() + (new Date().getMonth() >= 1 ? 1 : 0), 1, 14).getTime() },
    { id: uid(), title: "Visit Home ✈️", date: soon(48) },
  ]);
  DB.set("seeded", true);
}
