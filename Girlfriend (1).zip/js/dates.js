/* ============================================================
   dates.js — date ideas
   ============================================================ */

const DATE_SEED = [
  { t: "Virtual Movie Night", d: "Start the same movie at the same time on video call.", cat: "Virtual", tag: "🎬" },
  { t: "Cook the Same Recipe", d: "Pick one recipe, cook together over video, eat 'together'.", cat: "Food", tag: "🍕" },
  { t: "Online Game Night", d: "Play a co-op or party game online and trash talk lovingly.", cat: "Virtual", tag: "🎮" },
  { t: "Future Trip Planning", d: "Build a dream itinerary for a trip you'll take together.", cat: "Adventure", tag: "✈️" },
  { t: "Sunset Sync", d: "Watch the sunset at the same time and send pics.", cat: "Intimate", tag: "🌙" },
  { t: "Read to Each Other", d: "Take turns reading a chapter of a book out loud.", cat: "Creative", tag: "📖" },
  { t: "Virtual Museum Tour", d: "Explore a famous museum's online tour together.", cat: "Virtual", tag: "🖼️" },
  { t: "Spotify Blend Date", d: "Make a shared playlist, take turns adding songs.", cat: "Creative", tag: "🎵" },
  { t: "Draw Each Other", d: "Open the drawing game and sketch portraits.", cat: "Creative", tag: "🎨" },
  { t: "Coffee Date Call", d: "Both grab a coffee and just talk, no agenda.", cat: "Intimate", tag: "☕" },
  { t: "Stargazing Together", d: "Use a star map app and find constellations on call.", cat: "Adventure", tag: "⭐" },
  { t: "Takeout Roulette", d: "Order each other a surprise meal from afar.", cat: "Food", tag: "🍜" },
  { t: "Workout Buddy Date", d: "Do the same home workout on video.", cat: "Adventure", tag: "🏃" },
  { t: "Truth or Dare", d: "Sweet & silly truth or dare over video.", cat: "Intimate", tag: "💋" },
  { t: "Build a Playlist of 'Us'", d: "Songs that remind you of each other.", cat: "Creative", tag: "🎶" },
  { t: "Bake-Off Challenge", d: "Bake the same thing, judge each other's results.", cat: "Food", tag: "🧁" },
  { t: "Virtual Escape Room", d: "Solve an online escape room together.", cat: "Virtual", tag: "🔐" },
  { t: "Memory Slideshow", d: "Make a slideshow of favorite photos and watch it.", cat: "Intimate", tag: "📸" },
  { t: "Language Lesson", d: "Teach each other words in a new language.", cat: "Creative", tag: "🗣️" },
  { t: "Plan Our Dream Home", d: "Design rooms of your future home together.", cat: "Adventure", tag: "🏡" },
  { t: "Wine & Paint Night", d: "Paint the same reference picture, compare.", cat: "Creative", tag: "🍷" },
  { t: "Comfort Show Marathon", d: "Binge a cozy series in sync.", cat: "Virtual", tag: "📺" },
  { t: "Letter Writing", d: "Handwrite a letter, photograph and send it.", cat: "Intimate", tag: "💌" },
  { t: "Trivia Night", d: "Quiz each other or play online trivia.", cat: "Virtual", tag: "🧠" },
  { t: "Virtual Aquarium Visit", d: "Watch a live aquarium cam together.", cat: "Virtual", tag: "🐠" },
  { t: "Dream Bucket List", d: "Write 10 things to do together someday.", cat: "Adventure", tag: "📝" },
  { t: "Karaoke Call", d: "Sing your hearts out (badly) together.", cat: "Creative", tag: "🎤" },
  { t: "Dessert Date", d: "Each get a dessert and feed the screen lol.", cat: "Food", tag: "🍰" },
  { t: "Photo Scavenger Hunt", d: "Send pics matching a theme within 10 min.", cat: "Adventure", tag: "📷" },
  { t: "Candlelit Call", d: "Dim the lights, light candles, slow conversation.", cat: "Intimate", tag: "🕯️" },
  { t: "Plan a Surprise", d: "Secretly plan something for a third person together.", cat: "Adventure", tag: "🎁" },
  { t: "Watch the Sunrise", d: "Whoever's earlier wakes the other for sunrise.", cat: "Intimate", tag: "🌅" },
  { t: "DIY Craft Date", d: "Make something with materials at home.", cat: "Creative", tag: "✂️" },
  { t: "Virtual City Walk", d: "Take a Google Street View walk in a dream city.", cat: "Virtual", tag: "🚶" },
  { t: "Recipe Swap", d: "Cook a dish from each other's culture.", cat: "Food", tag: "🍲" },
  { t: "20 Questions", d: "Deep or silly — keep asking till you run out.", cat: "Intimate", tag: "❓" },
  { t: "Build in Minecraft", d: "Build a house together in a game.", cat: "Virtual", tag: "🧱" },
  { t: "Couples Yoga", d: "Follow a calming yoga video together.", cat: "Adventure", tag: "🧘" },
  { t: "Tea Tasting", d: "Brew different teas and describe them.", cat: "Food", tag: "🍵" },
  { t: "Make a Vision Board", d: "Create a shared vision board for the year.", cat: "Creative", tag: "🌈" },
  { t: "Movie Quote Game", d: "Guess movies from quotes you text.", cat: "Virtual", tag: "🎞️" },
  { t: "Late Night Drive Call", d: "Talk while one of you drives (hands-free!).", cat: "Intimate", tag: "🚗" },
  { t: "Window Shopping", d: "Browse an online store, pick gifts for each other.", cat: "Adventure", tag: "🛍️" },
  { t: "Couple's Quiz", d: "Take a 'how well do you know me' quiz.", cat: "Virtual", tag: "💑" },
  { t: "Pizza Topping Battle", d: "Build the weirdest pizza and dare to eat it.", cat: "Food", tag: "🍕" },
  { t: "Write a Story Together", d: "One sentence each, build a silly story.", cat: "Creative", tag: "✍️" },
  { t: "Plant Date", d: "Get matching plants and grow them together.", cat: "Adventure", tag: "🪴" },
  { t: "Slow Dance Call", d: "Pick a song and slow dance on video.", cat: "Intimate", tag: "💃" },
  { t: "Podcast Listen-Along", d: "Listen to an episode and pause to chat.", cat: "Virtual", tag: "🎧" },
  { t: "Bible Study Together", d: "Read a passage and reflect together.", cat: "Intimate", tag: "📖" },
  { t: "Breakfast in Sync", d: "Make the same breakfast on a weekend call.", cat: "Food", tag: "🥞" },
];

const Dates = {
  cat: "All",
  list() {
    let custom = DB.get("dates", null);
    if (!custom) { custom = DATE_SEED.map((d) => ({ id: uid(), ...d, done: false })); DB.set("dates", custom); }
    return custom;
  },
  cats() { return ["All", "Virtual", "Food", "Adventure", "Creative", "Intimate"]; },

  render() {
    const el = document.getElementById("dates");
    const all = this.list();
    const shown = this.cat === "All" ? all : all.filter((d) => d.cat === this.cat);
    const doneCount = all.filter((d) => d.done).length;
    el.innerHTML = `
      ${UI.topbar("Date Ideas", `💡 ${doneCount}/${all.length} done together`)}
      <div class="row" style="gap:8px;margin-bottom:12px">
        <button class="btn primary grow heartbeat" onclick="Dates.random()">🎲 Random date</button>
        <button class="btn ghost" onclick="Dates.add()">＋ Add</button>
      </div>
      <div class="cat-tabs">
        ${this.cats().map((c) => `<button class="cat-tab ${c===this.cat?"on":""}" onclick="Dates.setCat('${c}')">${c}</button>`).join("")}
      </div>
      <div id="dateList">
        ${shown.map((d) => this.card(d)).join("")}
      </div>`;
  },
  card(d) {
    return `<div class="date-card ${d.done?"done":""}">
      <div class="row between"><h3>${UI.esc(d.t)}</h3><span class="chip sage">${d.tag} ${d.cat}</span></div>
      <p>${UI.esc(d.d)}</p>
      <div class="row" style="gap:8px">
        <button class="btn sm ${d.done?"ghost":"sage"}" onclick="Dates.toggle('${d.id}')">${d.done?"↩️ Undo":"✓ Mark as done"}</button>
        <button class="btn sm ghost" onclick="Dates.schedule('${d.id}')">🗓️ Schedule</button>
      </div>
    </div>`;
  },
  setCat(c) { this.cat = c; this.render(); },
  toggle(id) {
    const all = this.list(); const d = all.find((x) => x.id === id);
    d.done = !d.done; DB.set("dates", all);
    if (d.done) { UI.floaty("💖"); logActivity("💡", `You did a date: ${d.t}`); Coins.add(2); }
    this.render();
  },
  random() {
    const all = this.list().filter((d) => !d.done);
    const pick = (all.length ? all : this.list())[Math.floor(Math.random() * (all.length ? all.length : this.list().length))];
    UI.modal(`<div class="center"><div style="font-size:34px">${pick.tag}</div>
      <div class="muted" style="font-size:12px;margin:4px 0">Your random date</div></div>
      <h3 style="text-align:center">${UI.esc(pick.t)}</h3>
      <p class="center muted" style="margin-bottom:16px">${UI.esc(pick.d)}</p>
      <button class="btn primary block" onclick="Dates.toggle('${pick.id}');UI.closeModal()">✓ We'll do this!</button>
      <button class="btn ghost block mt-s" onclick="Dates.random()">🎲 Another</button>`);
  },
  add() {
    UI.modal(`<h3>Add your own date 💡</h3>
      <div class="field-group"><label>Title</label><input id="ndT" placeholder="Our idea…" /></div>
      <div class="field-group"><label>Description</label><textarea id="ndD" rows="3"></textarea></div>
      <div class="field-group"><label>Category</label>
        <select id="ndC">${this.cats().slice(1).map((c) => `<option>${c}</option>`).join("")}</select></div>
      <button class="btn primary block" onclick="Dates.saveNew()">Add date idea</button>`);
  },
  saveNew() {
    const t = document.getElementById("ndT").value.trim();
    const d = document.getElementById("ndD").value.trim();
    const cat = document.getElementById("ndC").value;
    if (!t) { UI.toast("Give it a title 💭"); return; }
    const all = this.list();
    all.unshift({ id: uid(), t, d, cat, tag: "💞", done: false });
    DB.set("dates", all); UI.closeModal(); this.render();
  },
  schedule(id) {
    const d = this.list().find((x) => x.id === id);
    const when = prompt("Schedule for (e.g. 'Fri 8pm'):", "");
    if (when) {
      const cds = DB.get("countdowns", []);
      const date = new Date(when);
      cds.push({ id: uid(), title: "💡 " + d.t, date: isNaN(date) ? Date.now() + 3 * 86400000 : date.getTime() });
      DB.set("countdowns", cds);
      UI.toast("Added to your countdowns ⏳");
    }
  },
};
