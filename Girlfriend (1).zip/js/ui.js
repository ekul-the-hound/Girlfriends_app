/* ============================================================
   ui.js — router, page transitions, modal, toast, fx, helpers
   ============================================================ */

const Routes = {
  home: () => Home.render(),
  messages: () => Messages.render(),
  diary: () => Diary.render(),
  questions: () => Questions.render(),
  games: () => Games.render(),
  "game-wyr": () => Games.wyr(),
  "game-memory": () => Games.memory(),
  "game-checkers": () => Games.checkers(),
  pet: () => Pet.render(),
  dates: () => Dates.render(),
  gallery: () => Gallery.render(),
  stats: () => Stats.render(),
  prayer: () => Prayer.render(),
  settings: () => Settings.render(),
};
const TAB_PAGES = ["home", "messages", "diary", "games", "pet"];

const UI = {
  /* ---------- navigation ---------- */
  go(id, opts = {}) {
    const pages = document.querySelectorAll(".page");
    const target = document.getElementById(id);
    if (!target) return;
    // render content
    if (Routes[id]) Routes[id]();
    pages.forEach((p) => p.classList.remove("active", "slide"));
    target.classList.add("active");
    if (opts.slide) target.classList.add("slide");
    App.current = id;
    // scroll to top
    target.scrollTop = 0;
    window.scrollTo(0, 0);
    // tab highlight
    const tabPage = TAB_PAGES.includes(id) ? id
      : (id.startsWith("game") ? "games" : null);
    document.querySelectorAll(".tab").forEach((t) =>
      t.classList.toggle("active", t.dataset.go === tabPage));
    if (history && id !== "home") location.hash = id; else if (id === "home") location.hash = "";
  },

  topbar(title, sub, backTo = "home") {
    return `<div class="topbar">
      <button class="back" onclick="UI.go('${backTo}',{slide:true})">‹</button>
      <div><h2>${title}</h2>${sub ? `<div class="sub">${sub}</div>` : ""}</div>
    </div>`;
  },

  /* ---------- modal ---------- */
  modal(html) {
    const bg = document.getElementById("modalBg");
    document.getElementById("modal").innerHTML = `<div class="grab"></div>` + html;
    bg.classList.add("on");
  },
  closeModal() { document.getElementById("modalBg").classList.remove("on"); },

  /* ---------- toast ---------- */
  toast(msg) {
    const el = document.createElement("div");
    el.className = "toast";
    el.textContent = msg;
    document.getElementById("toasts").appendChild(el);
    setTimeout(() => el.remove(), 2600);
  },

  /* ---------- floating emoji pop ---------- */
  floaty(emoji, ev) {
    const el = document.createElement("div");
    el.className = "floaty";
    el.textContent = emoji;
    let x = window.innerWidth / 2, y = window.innerHeight / 2;
    if (ev && ev.clientX) { x = ev.clientX; y = ev.clientY; }
    el.style.left = x - 12 + "px";
    el.style.top = y - 12 + "px";
    document.getElementById("fx").appendChild(el);
    setTimeout(() => el.remove(), 1300);
  },

  /* ---------- confetti burst ---------- */
  confetti(n = 80) {
    const fx = document.getElementById("fx");
    const colors = ["#D4A5A5", "#C8B8E8", "#B8C5B6", "#f3d2d2", "#ffe0b3"];
    for (let i = 0; i < n; i++) {
      const c = document.createElement("div");
      c.className = "confetti";
      c.style.background = colors[i % colors.length];
      c.style.left = Math.random() * 100 + "vw";
      c.style.top = "-12px";
      const dx = (Math.random() - 0.5) * 240;
      const dur = 1.6 + Math.random() * 1.4;
      const rot = Math.random() * 720;
      c.style.borderRadius = Math.random() > 0.5 ? "50%" : "2px";
      fx.appendChild(c);
      c.animate(
        [{ transform: "translate(0,0) rotate(0)", opacity: 1 },
         { transform: `translate(${dx}px, ${window.innerHeight + 40}px) rotate(${rot}deg)`, opacity: 1 },
         { opacity: 0 }],
        { duration: dur * 1000, easing: "cubic-bezier(.3,.6,.6,1)" }
      ).onfinish = () => c.remove();
    }
  },

  /* ---------- file → base64 (with downscale) ---------- */
  pickImage(maxSize = 1100) {
    return new Promise((resolve) => {
      const input = document.getElementById("filePick");
      input.value = "";
      input.onchange = () => {
        const file = input.files[0];
        if (!file) return resolve(null);
        const reader = new FileReader();
        reader.onload = () => {
          const img = new Image();
          img.onload = () => {
            let { width: w, height: h } = img;
            const scale = Math.min(1, maxSize / Math.max(w, h));
            w = Math.round(w * scale); h = Math.round(h * scale);
            const cv = document.createElement("canvas");
            cv.width = w; cv.height = h;
            cv.getContext("2d").drawImage(img, 0, 0, w, h);
            resolve(cv.toDataURL("image/jpeg", 0.82));
          };
          img.src = reader.result;
        };
        reader.readAsDataURL(file);
      };
      input.click();
    });
  },

  esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  },
  empty(emoji, text) {
    return `<div class="empty-note"><div style="font-size:34px">${emoji}</div><div class="mt-s">${text}</div></div>`;
  },
};

/* close modal / lightbox on backdrop click + global wiring (set in app.js) */
