/* ============================================================
   draw.js — full-screen drawing canvas (Draw For Each Other)
   ============================================================ */

const Draw = {
  tool: "pen",
  color: "#D4A5A5",
  size: 6,
  to: "Sophie",
  drawing: false,
  last: null,

  open(to) {
    this.to = to || "Sophie";
    const host = document.getElementById("drawHost");
    host.innerHTML = `
      <div class="draw-stage" id="drawStage">
        <div class="draw-top">
          <button class="icon-btn" onclick="Draw.close()">‹</button>
          <div class="grow">
            <div style="font-weight:800;font-family:var(--font-head)">🎨 Drawing for
              <select id="drawTo" style="border:none;background:var(--bg-tint);border-radius:8px;padding:3px 8px;font-weight:800">
                <option ${this.to==="Sophie"?"selected":""}>Sophie</option>
                <option ${this.to==="Luke"?"selected":""}>Luke</option>
              </select></div>
          </div>
          <button class="btn sm ghost" onclick="Draw.clear()">Clear</button>
          <button class="btn sm primary" onclick="Draw.send()">Send 💌</button>
        </div>
        <div class="draw-canvas-wrap"><canvas id="drawCanvas"></canvas></div>
        <div class="draw-toolbar" id="drawTools">
          ${["pen","brush","airbrush","eraser"].map((t) => `
            <button class="tool ${t===this.tool?"on":""}" data-tool="${t}" onclick="Draw.setTool('${t}')">${{pen:"✏️",brush:"🖌️",airbrush:"💨",eraser:"🧽"}[t]}</button>`).join("")}
          <div style="width:1px;height:30px;background:var(--line);flex:none"></div>
          ${["#D4A5A5","#C8B8E8","#B8C5B6","#2C2C2C","#E8A0BF","#F2C14E","#6DA9E4","#fff"].map((col) => `
            <div class="swatch ${col===this.color?"on":""}" data-col="${col}" style="background:${col}" onclick="Draw.setColor('${col}')"></div>`).join("")}
          <input type="color" id="drawCustom" value="#D4A5A5" onchange="Draw.setColor(this.value)" style="width:34px;height:34px;border:none;background:none;flex:none" />
          <div style="width:1px;height:30px;background:var(--line);flex:none"></div>
          ${["❤️","⭐","💋","🌸","✨"].map((st) => `<button class="tool" onclick="Draw.setStamp('${st}')">${st}</button>`).join("")}
          <input type="range" min="2" max="40" value="${this.size}" oninput="Draw.size=+this.value" style="flex:none;width:80px" />
        </div>
      </div>`;
    document.getElementById("drawTo").onchange = (e) => this.to = e.target.value;
    requestAnimationFrame(() => this.setup());
  },

  setup() {
    const cv = document.getElementById("drawCanvas");
    const wrap = cv.parentElement;
    cv.width = wrap.clientWidth; cv.height = wrap.clientHeight;
    this.ctx = cv.getContext("2d");
    this.ctx.fillStyle = "#fff"; this.ctx.fillRect(0, 0, cv.width, cv.height);
    this.ctx.lineCap = "round"; this.ctx.lineJoin = "round";
    this.stamp = null;
    const pos = (e) => {
      const r = cv.getBoundingClientRect();
      const t = e.touches ? e.touches[0] : e;
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    };
    const start = (e) => { e.preventDefault(); this.drawing = true; this.last = pos(e); if (this.stamp) this.placeStamp(this.last); else this.stroke(this.last, this.last); };
    const move = (e) => { if (!this.drawing) return; e.preventDefault(); const p = pos(e); if (!this.stamp) this.stroke(this.last, p); this.last = p; };
    const end = () => { this.drawing = false; };
    cv.onmousedown = start; cv.onmousemove = move; window.onmouseup = end;
    cv.ontouchstart = start; cv.ontouchmove = move; cv.ontouchend = end;
  },

  stroke(a, b) {
    const ctx = this.ctx;
    if (this.tool === "eraser") { ctx.strokeStyle = "#fff"; ctx.globalAlpha = 1; ctx.lineWidth = this.size * 2.2; }
    else if (this.tool === "airbrush") {
      ctx.fillStyle = this.color;
      for (let i = 0; i < 12; i++) {
        const a2 = Math.random() * Math.PI * 2, r = Math.random() * this.size;
        ctx.globalAlpha = 0.25;
        ctx.beginPath(); ctx.arc(b.x + Math.cos(a2) * r, b.y + Math.sin(a2) * r, 1.2, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1; return;
    } else { ctx.strokeStyle = this.color; ctx.globalAlpha = this.tool === "brush" ? 0.85 : 1; ctx.lineWidth = this.tool === "brush" ? this.size * 1.6 : this.size; }
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.globalAlpha = 1;
  },
  placeStamp(p) {
    const ctx = this.ctx;
    ctx.font = (this.size * 4) + "px serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(this.stamp, p.x, p.y);
  },

  setTool(t) { this.tool = t; this.stamp = null; document.querySelectorAll("#drawTools .tool").forEach((b) => b.classList.toggle("on", b.dataset.tool === t)); },
  setColor(c) { this.color = c; this.tool = this.tool === "eraser" ? "pen" : this.tool; this.stamp = null;
    document.querySelectorAll("#drawTools .swatch").forEach((s) => s.classList.toggle("on", s.dataset.col === c));
    document.querySelectorAll("#drawTools .tool").forEach((b) => b.classList.toggle("on", b.dataset.tool === this.tool)); },
  setStamp(s) { this.stamp = s; UI.toast(`Tap to place ${s}`); },

  clear() {
    const cv = document.getElementById("drawCanvas");
    this.ctx.fillStyle = "#fff"; this.ctx.fillRect(0, 0, cv.width, cv.height);
  },
  send() {
    const cv = document.getElementById("drawCanvas");
    const img = cv.toDataURL("image/png");
    const from = this.to === "Sophie" ? "Luke" : "Sophie";
    const list = DB.get("drawings", []);
    list.unshift({ id: uid(), img, to: this.to, from, ts: Date.now() });
    DB.set("drawings", list.slice(0, 40));
    Streaks.did("draw");
    Coins.add(3);
    logActivity("🎨", `${from} drew something for ${this.to}`);
    UI.confetti(40);
    this.close();
    UI.toast(`Sent to ${this.to}! 💌`);
  },
  close() { document.getElementById("drawHost").innerHTML = ""; window.onmouseup = null; },
};
