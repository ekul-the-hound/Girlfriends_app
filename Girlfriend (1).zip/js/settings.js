/* ============================================================
   settings.js — settings, night mode, love map, data import/export
   ============================================================ */

const Settings = {
  get() {
    return DB.get("settings", { night: false, notifications: false,
      lukeLoc: "", sophieLoc: "", lukeLat: null, lukeLon: null, sophieLat: null, sophieLon: null });
  },
  set(s) { DB.set("settings", s); },

  render() {
    const s = this.get();
    const el = document.getElementById("settings");
    const start = DB.get("relStart", RELATIONSHIP_START);
    const pet = Pet.data();
    el.innerHTML = `
      ${UI.topbar("Settings", "⚙️ make it yours")}

      <div class="section-label">🗺️ Love Map</div>
      ${this.loveMap(s)}

      <div class="section-label">Appearance</div>
      <div class="card">
        <div class="set-row">
          <div class="ic">🌙</div>
          <div class="body"><div class="t">Night mode</div><div class="s">Soft purples for late-night chats</div></div>
          <div class="toggle ${s.night?"on":""}" onclick="Settings.toggleNight()"><i></i></div>
        </div>
        <div class="set-row">
          <div class="ic">🔔</div>
          <div class="body"><div class="t">Reminders</div><div class="s">Daily questions, pet care &amp; messages</div></div>
          <div class="toggle ${s.notifications?"on":""}" onclick="Settings.toggleNotif()"><i></i></div>
        </div>
      </div>

      <div class="section-label">Personalize</div>
      <div class="card">
        <div class="set-row">
          <div class="ic">🐶</div>
          <div class="body"><div class="t">Pet name</div><div class="s">${UI.esc(pet.name)}</div></div>
          <button class="btn sm ghost" onclick="Pet.rename();Settings.render()">Edit</button>
        </div>
        <div class="set-row">
          <div class="ic">💖</div>
          <div class="body"><div class="t">Together since</div><div class="s">${fmtDate(new Date(start).getTime())} · ${daysBetween(start,Date.now())} days</div></div>
          <input type="date" value="${start}" onchange="Settings.setStart(this.value)" style="border:1px solid var(--line);border-radius:8px;padding:5px" />
        </div>
        <div class="set-row">
          <div class="ic">🦂</div>
          <div class="body"><div class="t">Avatars</div><div class="s">Luke 🦂 · Sophie 🌸</div></div>
        </div>
      </div>

      <div class="section-label">Your data</div>
      <div class="card">
        <div class="set-row">
          <div class="ic">📤</div>
          <div class="body"><div class="t">Export everything</div><div class="s">Save a backup as JSON</div></div>
          <button class="btn sm sage" onclick="Settings.export()">Export</button>
        </div>
        <div class="set-row">
          <div class="ic">📥</div>
          <div class="body"><div class="t">Import backup</div><div class="s">Restore from a JSON file</div></div>
          <button class="btn sm ghost" onclick="Settings.importData()">Import</button>
        </div>
        <div class="set-row">
          <div class="ic">🗑️</div>
          <div class="body"><div class="t">Reset everything</div><div class="s">Clear all data on this device</div></div>
          <button class="btn sm ghost" onclick="Settings.reset()" style="color:var(--rose-deep)">Reset</button>
        </div>
      </div>

      <div class="center muted mt" style="font-size:12px;padding:14px">
        Made with 💖 for Luke &amp; Sophie<br>Our Corner · a private little home
      </div>
      <input type="file" id="importPick" accept="application/json" class="hidden" />`;
  },

  loveMap(s) {
    let dist = "";
    if (s.lukeLat != null && s.sophieLat != null) {
      const km = this.haversine(s.lukeLat, s.lukeLon, s.sophieLat, s.sophieLon);
      dist = `<div class="center" style="padding:10px 0">
        <div style="font-family:var(--font-head);font-weight:800;font-size:28px;color:var(--lavender-deep)">${Math.round(km).toLocaleString()} km</div>
        <div class="muted" style="font-size:12px">${Math.round(km*0.621).toLocaleString()} miles apart — but not for long 💕</div></div>`;
    }
    return `<div class="card">
      <div style="display:flex;align-items:center;justify-content:space-around;padding:6px 0 12px">
        <div class="center"><div style="font-size:30px">🦂</div><div style="font-size:12px;font-weight:700">${UI.esc(s.lukeLoc||"Luke")}</div></div>
        <div style="flex:1;height:2px;background:repeating-linear-gradient(90deg,var(--rose) 0 6px,transparent 6px 12px);margin:0 10px;position:relative">
          <span style="position:absolute;top:-12px;left:50%;transform:translateX(-50%)">✈️</span></div>
        <div class="center"><div style="font-size:30px">🌸</div><div style="font-size:12px;font-weight:700">${UI.esc(s.sophieLoc||"Sophie")}</div></div>
      </div>
      ${dist}
      <div class="row" style="gap:8px">
        <input id="lukeLoc" placeholder="Luke's city" value="${UI.esc(s.lukeLoc)}" style="flex:1;border:1px solid var(--line);border-radius:10px;padding:9px" />
        <input id="sophieLoc" placeholder="Sophie's city" value="${UI.esc(s.sophieLoc)}" style="flex:1;border:1px solid var(--line);border-radius:10px;padding:9px" />
      </div>
      <button class="btn ghost block mt-s" onclick="Settings.saveLocations()">📍 Update distance</button>
    </div>`;
  },
  haversine(lat1, lon1, lat2, lon2) {
    const R = 6371, toR = (d) => d * Math.PI / 180;
    const dLat = toR(lat2 - lat1), dLon = toR(lon2 - lon1);
    const a = Math.sin(dLat/2)**2 + Math.cos(toR(lat1))*Math.cos(toR(lat2))*Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  },
  async saveLocations() {
    const s = this.get();
    s.lukeLoc = document.getElementById("lukeLoc").value.trim();
    s.sophieLoc = document.getElementById("sophieLoc").value.trim();
    UI.toast("Looking up cities… 📍");
    const geo = async (city) => {
      try {
        const r = await fetch(`https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(city)}`);
        const j = await r.json();
        return j[0] ? { lat: +j[0].lat, lon: +j[0].lon } : null;
      } catch (e) { return null; }
    };
    const [a, b] = await Promise.all([geo(s.lukeLoc), geo(s.sophieLoc)]);
    if (a) { s.lukeLat = a.lat; s.lukeLon = a.lon; }
    if (b) { s.sophieLat = b.lat; s.sophieLon = b.lon; }
    this.set(s);
    this.render();
    if (!a || !b) UI.toast("Couldn't find one city — try being more specific");
  },

  toggleNight() {
    const s = this.get(); s.night = !s.night; this.set(s);
    document.body.classList.toggle("night", s.night);
    document.querySelector('meta[name="theme-color"]').setAttribute("content", s.night ? "#17141f" : "#F9F5F0");
    this.render();
  },
  toggleNotif() {
    const s = this.get();
    if (!s.notifications && "Notification" in window) {
      Notification.requestPermission().then((perm) => {
        s.notifications = perm === "granted"; this.set(s);
        if (s.notifications) { UI.toast("Reminders on 🔔"); this.scheduleReminders(); }
        else UI.toast("Notifications blocked in browser");
        this.render();
      });
    } else { s.notifications = false; this.set(s); this.render(); }
  },
  scheduleReminders() {
    // gentle in-session reminder demo
    setTimeout(() => {
      if (Notification.permission === "granted" && !Questions.state().luke) {
        new Notification("Our Corner 💖", { body: "Don't forget today's question & to feed your puppy 🐶" });
      }
    }, 60000);
  },
  setStart(v) { DB.set("relStart", v); this.render(); },

  /* ---------- data ---------- */
  export() {
    const data = {};
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k.startsWith("ourCorner_")) data[k] = localStorage.getItem(k);
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `our-corner-backup-${todayKey()}.json`;
    a.click();
    UI.toast("Backup downloaded 📤");
  },
  importData() {
    const inp = document.getElementById("importPick");
    inp.value = "";
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          Object.entries(data).forEach(([k, v]) => { if (k.startsWith("ourCorner_")) localStorage.setItem(k, v); });
          UI.toast("Backup restored 📥");
          location.reload();
        } catch (e) { UI.toast("Couldn't read that file"); }
      };
      reader.readAsText(f);
    };
    inp.click();
  },
  reset() {
    if (!confirm("This clears ALL data on this device. Are you sure?")) return;
    if (!confirm("Really sure? This can't be undone.")) return;
    Object.keys(localStorage).filter((k) => k.startsWith("ourCorner_")).forEach((k) => localStorage.removeItem(k));
    location.reload();
  },
};
