/* ============================================================
   games.js — hub + Would You Rather + Memory + Checkers + Drawing
   ============================================================ */

const Games = {
  render() {
    const el = document.getElementById("games");
    el.innerHTML = `
      ${UI.topbar("Games", "🎮 play together, anywhere")}
      <div class="game-grid">
        <button class="game-tile wyr" onclick="UI.go('game-wyr',{slide:true})">
          <span class="ic">🤔</span><h3>Would You<br>Rather</h3><p>Pick, reveal, debate</p></button>
        <button class="game-tile mem" onclick="UI.go('game-memory',{slide:true})">
          <span class="ic">🧠</span><h3>Memory<br>Match</h3><p>Find the pairs</p></button>
        <button class="game-tile check" onclick="UI.go('game-checkers',{slide:true})">
          <span class="ic">♟️</span><h3>Checkers</h3><p>🦂 vs 🌸 · saved</p></button>
        <button class="game-tile draw" onclick="Games.draw('Sophie')">
          <span class="ic">🎨</span><h3>Draw For<br>Each Other</h3><p>Doodle &amp; send</p></button>
      </div>
      <div class="section-label">Drawings inbox 🖼️</div>
      <div class="card flat">${this.drawingInbox()}</div>`;
  },

  /* =========================================================
     A. WOULD YOU RATHER
     ========================================================= */
  wyr() {
    const el = document.getElementById("game-wyr");
    const s = this._wyrState || (this._wyrState = { i: Math.floor(Math.random() * WYR.length), luke: null, sophie: null });
    const q = WYR[s.i];
    const both = s.luke && s.sophie;
    el.innerHTML = `
      ${UI.topbar("Would You Rather", "🤔 both pick, then reveal", "games")}
      <div class="center mb">
        <span class="chip ${q.spicy ? "rose" : "sage"}">${q.spicy ? "🌶️ spicy" : "🎈 silly"}</span>
      </div>
      <div class="row between" style="margin:10px 0">
        <div class="who-toggle">
          <button class="luke ${App.who==="luke"?"on":""}" onclick="Games.wyrWho('luke')">🦂 Luke</button>
          <button class="sophie ${App.who==="sophie"?"on":""}" onclick="Games.wyrWho('sophie')">🌸 Sophie</button>
        </div>
        <span class="muted" style="font-size:11px">${PEOPLE[App.who].name}'s turn</span>
      </div>
      <div class="wyr-stage">
        <div class="wyr-opt a" onclick="Games.wyrPick('a')">${UI.esc(q.a)}${both ? `<span class="pct">${s.luke==="a"?"🦂":""}${s.sophie==="a"?"🌸":""}</span>`:""}</div>
        <div class="wyr-or">— or —</div>
        <div class="wyr-opt b" onclick="Games.wyrPick('b')">${UI.esc(q.b)}${both ? `<span class="pct">${s.luke==="b"?"🦂":""}${s.sophie==="b"?"🌸":""}</span>`:""}</div>
      </div>
      ${both ? `<div class="match-banner">${s.luke===s.sophie ? "❤️ You both chose the same!" : "😆 Opposites attract — discuss!"}</div>
        <button class="btn primary block heartbeat" onclick="Games.wyrNext()">Next question →</button>`
        : `<div class="center muted mt" style="font-size:12px">${(s.luke||s.sophie) ? "One picked — switch player to reveal" : "Tap an option to choose"}</div>`}
      <div class="center mt"><button class="btn ghost sm" onclick="Games.wyrNext()">🎲 Shuffle</button></div>`;
  },
  wyrWho(w) { App.setWho(w); this.wyr(); },
  wyrPick(side) {
    const s = this._wyrState;
    if (s.luke && s.sophie) return;
    s[App.who] = side;
    UI.floaty("👉");
    if (s.luke && s.sophie) { Coins.add(2); logActivity("🤔","You played Would You Rather"); }
    this.wyr();
  },
  wyrNext() {
    this._wyrState = { i: Math.floor(Math.random() * WYR.length), luke: null, sophie: null };
    this.wyr();
  },

  /* =========================================================
     B. MEMORY MATCH
     ========================================================= */
  memory() {
    const el = document.getElementById("game-memory");
    const icons = ["❤️","⭐","🌸","🦂","🌙","🐶","☕","🎵"];
    if (!this._mem || this._mem.done) {
      const deck = [...icons, ...icons].map((ic) => ({ ic, flip: false, done: false }))
        .sort(() => Math.random() - 0.5).map((c, i) => ({ ...c, id: i }));
      this._mem = { deck, first: null, lock: false, moves: 0, matched: 0, done: false };
    }
    const m = this._mem;
    el.innerHTML = `
      ${UI.topbar("Memory Match", "🧠 find all 8 pairs", "games")}
      <div class="row between" style="margin-bottom:14px">
        <span class="chip lav">Moves: <b id="memMoves">${m.moves}</b></span>
        <span class="chip sage">Pairs: <b id="memPairs">${m.matched}</b>/8</span>
        <button class="btn ghost sm" onclick="Games._mem=null;Games.memory()">🔄 Reset</button>
      </div>
      <div class="mem-grid">
        ${m.deck.map((c) => `
          <div class="mem-card ${c.flip||c.done?"flip":""} ${c.done?"done":""}" onclick="Games.memFlip(${c.id})">
            <div class="face back">💞</div>
            <div class="face front">${c.ic}</div>
          </div>`).join("")}
      </div>`;
  },
  memFlip(id) {
    const m = this._mem;
    if (m.lock) return;
    const card = m.deck[id];
    if (card.flip || card.done) return;
    card.flip = true;
    this.memRefreshCard(id);
    if (m.first == null) { m.first = id; return; }
    m.moves++; document.getElementById("memMoves").textContent = m.moves;
    m.lock = true;
    const a = m.deck[m.first], b = card;
    if (a.ic === b.ic) {
      setTimeout(() => {
        a.done = b.done = true; m.matched++;
        document.getElementById("memPairs").textContent = m.matched;
        m.first = null; m.lock = false;
        UI.floaty("✨");
        if (m.matched === 8) { m.done = true; UI.confetti(); UI.toast("You cleared the board! 💞"); Coins.add(5); logActivity("🧠","You won Memory Match"); }
      }, 450);
    } else {
      setTimeout(() => {
        a.flip = b.flip = false;
        this.memRefreshCard(m.first); this.memRefreshCard(id);
        m.first = null; m.lock = false;
      }, 800);
    }
  },
  memRefreshCard(id) {
    const m = this._mem;
    const cards = document.querySelectorAll("#game-memory .mem-card");
    const c = m.deck[id];
    if (cards[id]) cards[id].classList.toggle("flip", c.flip || c.done);
  },

  /* =========================================================
     C. CHECKERS  (delegated to checkers.js logic below)
     ========================================================= */
  checkers() { Checkers.render(); },

  /* =========================================================
     D. DRAWING (delegated)
     ========================================================= */
  draw(to) { Draw.open(to); },
  drawingInbox() {
    const list = DB.get("drawings", []);
    const mine = list.filter((d) => d.to === PEOPLE[App.who].name || d.to === App.who);
    if (!list.length) return UI.empty("🎨", "No drawings yet. Doodle something cute!");
    return `<div class="scrollx">${list.slice(0,12).map((d) => `
      <div style="flex:none;text-align:center" onclick="Gallery.openLightboxFor('${d.img}','For ${UI.esc(d.to)} — from ${UI.esc(d.from)}')">
        <img src="${d.img}" style="width:96px;height:96px;object-fit:cover;border-radius:12px;box-shadow:var(--shadow-soft);background:#fff" />
        <div style="font-size:10px;color:var(--ink-faint);margin-top:3px">for ${UI.esc(d.to)}</div>
      </div>`).join("")}</div>`;
  },
};

/* ---------- Would You Rather bank (50+) ---------- */
const WYR = [
  {a:"Have a daily 5-min video call",b:"One long 2-hour call weekly",spicy:false},
  {a:"Always cuddle while watching movies",b:"Always hold hands on walks",spicy:false},
  {a:"Travel the world together with no home",b:"Build one cozy home and stay",spicy:false},
  {a:"Surprise visit with no warning",b:"A planned trip you count down to",spicy:false},
  {a:"Sing me a song",b:"Write me a poem",spicy:false},
  {a:"Slow dance in the kitchen",b:"Stargaze on a rooftop",spicy:true},
  {a:"Forehead kisses forever",b:"Hand kisses forever",spicy:true},
  {a:"Matching tattoos",b:"Matching necklaces",spicy:false},
  {a:"Breakfast in bed every morning",b:"Late-night snacks every night",spicy:false},
  {a:"A puppy together",b:"A kitten together",spicy:false},
  {a:"Read the same book aloud",b:"Watch the same show in sync",spicy:false},
  {a:"Move to a beach town",b:"Move to a mountain cabin",spicy:false},
  {a:"Couple's cooking class",b:"Couple's dance class",spicy:false},
  {a:"Always say 'I love you' first",b:"Always be the one to plan dates",spicy:false},
  {a:"Tiny everyday adventures",b:"Rare big epic adventures",spicy:false},
  {a:"A love letter every week",b:"A voice note every morning",spicy:true},
  {a:"Hold hands in your sleep",b:"Whisper goodnight every night",spicy:true},
  {a:"Relive our first date",b:"Fast-forward to our wedding day",spicy:true},
  {a:"Picnic at sunrise",b:"Dinner at sunset",spicy:false},
  {a:"Get lost in a new city together",b:"Know every corner of your hometown together",spicy:false},
  {a:"Same coffee order forever",b:"Try a new café every week",spicy:false},
  {a:"Be famous as a couple",b:"Be quietly, privately in love",spicy:false},
  {a:"Win a million but spend it together fast",b:"Earn a steady life slowly together",spicy:false},
  {a:"A scrapbook of every memory",b:"A playlist for every mood",spicy:false},
  {a:"Endless rainy cozy days",b:"Endless sunny beach days",spicy:false},
  {a:"Plan everything in detail",b:"Be wonderfully spontaneous",spicy:false},
  {a:"Big loud family gatherings",b:"Quiet nights just us two",spicy:false},
  {a:"A garden we grow together",b:"A library we fill together",spicy:false},
  {a:"Learn each other's languages",b:"Invent our own secret language",spicy:true},
  {a:"Dance badly but freely",b:"Dance perfectly but stiff",spicy:false},
  {a:"Camp under the stars",b:"Fancy hotel with room service",spicy:false},
  {a:"Always be the big spoon",b:"Always be the little spoon",spicy:true},
  {a:"A road trip with no destination",b:"A flight to one dream place",spicy:false},
  {a:"Matching pajamas",b:"Matching mugs",spicy:false},
  {a:"Sunday morning markets",b:"Saturday night concerts",spicy:false},
  {a:"Reunite at the airport",b:"Reunite at your front door",spicy:true},
  {a:"A song that's 'ours'",b:"A place that's 'ours'",spicy:false},
  {a:"Cook together and make a mess",b:"Order in and stay clean",spicy:false},
  {a:"Write our story as a movie",b:"Write our story as a book",spicy:false},
  {a:"Always know what I'm thinking",b:"Always be surprised by me",spicy:false},
  {a:"A long hug at the door",b:"A long kiss goodnight",spicy:true},
  {a:"Grow old in the same town we met",b:"Grow old somewhere brand new",spicy:false},
  {a:"Breakfast date",b:"Midnight date",spicy:false},
  {a:"Hold the umbrella for me",b:"Share the umbrella and both get wet",spicy:false},
  {a:"A handwritten map of inside jokes",b:"A jar of date-night ideas",spicy:false},
  {a:"Spend a year traveling",b:"Spend a year building a home",spicy:false},
  {a:"Slow texts all day",b:"Two real long calls a day",spicy:false},
  {a:"Wear my hoodie",b:"Wear my favorite perfume/cologne",spicy:true},
  {a:"Paint a wall together",b:"Plant a tree together",spicy:false},
  {a:"A photo booth strip",b:"A polaroid wall",spicy:false},
  {a:"Forehead-to-forehead silence",b:"Talking till 4am",spicy:true},
  {a:"Be each other's first call good news",b:"Be each other's first call hard news",spicy:false},
];
