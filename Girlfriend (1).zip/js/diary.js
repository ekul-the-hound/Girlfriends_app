/* ============================================================
   diary.js — couple diary
   ============================================================ */

const Diary = {
  render() {
    const el = document.getElementById("diary");
    const entries = this.visible();
    el.innerHTML = `
      ${UI.topbar("Couple Diary", "📖 chapters of our story")}
      <div class="row" style="gap:8px;margin-bottom:14px">
        <button class="btn primary grow heartbeat" onclick="Diary.compose()">✍️ New entry</button>
        <button class="btn ghost" onclick="Diary.memoryLane()">🎲 Memory Lane</button>
        <button class="btn ghost" onclick="Diary.exportPdf()">📄</button>
      </div>
      <div id="diaryList">
        ${entries.length ? entries.map((e) => this.entry(e)).join("") : UI.empty("📖", "No entries yet. Write your first page 💕")}
      </div>`;
  },

  visible() {
    // hide entries marked private to the *other* person
    return DB.get("diary", []).filter((e) => !e.privateTo || e.privateTo === App.who)
      .sort((a, b) => b.date - a.date);
  },

  entry(e) {
    const p = PEOPLE[e.author];
    return `<div class="diary-entry ${p.cls}">
      ${e.privateTo ? `<span class="lock">🔒</span>` : ""}
      <div class="d">${p.emoji} ${p.name} · ${fmtDate(e.date)}</div>
      ${e.title ? `<h3>${UI.esc(e.title)}</h3>` : ""}
      <div class="txt">${UI.esc(e.text)}</div>
      ${e.images && e.images.length ? `<div class="imgs">${e.images.map((i) => `<img src="${i}" onclick="Gallery.openLightboxFor('${i}','Diary photo')" />`).join("")}</div>` : ""}
      ${e.tags && e.tags.length ? `<div class="tags">${e.tags.map((t) => `<span class="chip lav">#${UI.esc(t)}</span>`).join("")}</div>` : ""}
      <div class="row" style="margin-top:10px;gap:8px">
        <button class="btn sm ghost" onclick="Diary.edit('${e.id}')">Edit</button>
        <button class="btn sm ghost" onclick="Diary.del('${e.id}')">Delete</button>
      </div>
    </div>`;
  },

  compose(existing) {
    const e = existing || {};
    UI.modal(`
      <h3>${existing ? "Edit entry" : "New diary entry"} 📖</h3>
      <div class="field-group"><label>Writing as</label>
        <div class="who-toggle">
          <button class="luke ${(e.author||App.who)==="luke"?"on":""}" onclick="Diary._a='luke';this.parentNode.querySelectorAll('button').forEach(b=>b.classList.remove('on'));this.classList.add('on')">🦂 Luke</button>
          <button class="sophie ${(e.author||App.who)==="sophie"?"on":""}" onclick="Diary._a='sophie';this.parentNode.querySelectorAll('button').forEach(b=>b.classList.remove('on'));this.classList.add('on')">🌸 Sophie</button>
        </div></div>
      <div class="field-group"><label>Title (optional)</label>
        <input id="dTitle" value="${UI.esc(e.title||"")}" placeholder="A day to remember…" /></div>
      <div class="field-group"><label>Your words</label>
        <textarea id="dText" rows="6" placeholder="Dear diary…">${UI.esc(e.text||"")}</textarea></div>
      <div class="field-group"><label>Tags (comma separated)</label>
        <input id="dTags" value="${(e.tags||[]).join(", ")}" placeholder="firstcall, missyou, funny" /></div>
      <div class="field-group"><label>Privacy</label>
        <select id="dPriv">
          <option value="">Shared — both can read</option>
          <option value="luke" ${e.privateTo==="luke"?"selected":""}>🔒 Private to Luke</option>
          <option value="sophie" ${e.privateTo==="sophie"?"selected":""}>🔒 Private to Sophie</option>
        </select></div>
      <div id="dImgs" class="imgs" style="margin-bottom:12px">${(e.images||[]).map((i)=>`<img src="${i}" style="width:60px;height:60px;object-fit:cover;border-radius:10px" />`).join("")}</div>
      <div class="row" style="gap:8px">
        <button class="btn ghost" onclick="Diary.addPhoto()">📷 Photo</button>
        <button class="btn primary grow" onclick="Diary.save('${e.id||""}')">${existing ? "Save changes" : "Save entry"}</button>
      </div>`);
    this._a = e.author || App.who;
    this._imgs = (e.images || []).slice();
  },
  async addPhoto() {
    const img = await UI.pickImage(900);
    if (!img) return;
    this._imgs = this._imgs || [];
    this._imgs.push(img);
    document.getElementById("dImgs").innerHTML = this._imgs.map((i) => `<img src="${i}" style="width:60px;height:60px;object-fit:cover;border-radius:10px" />`).join("");
  },
  save(id) {
    const title = document.getElementById("dTitle").value.trim();
    const text = document.getElementById("dText").value.trim();
    if (!text) { UI.toast("Write a little something 💭"); return; }
    const tags = document.getElementById("dTags").value.split(",").map((t) => t.trim().replace(/^#/, "")).filter(Boolean);
    const privateTo = document.getElementById("dPriv").value || null;
    const list = DB.get("diary", []);
    if (id) {
      const e = list.find((x) => x.id === id);
      Object.assign(e, { title, text, tags, privateTo, author: this._a, images: this._imgs || [] });
    } else {
      list.push({ id: uid(), author: this._a || App.who, date: Date.now(), title, text, tags, images: this._imgs || [], privateTo });
      logActivity("📖", `${PEOPLE[this._a].name} wrote a diary entry`);
      Coins.add(2);
    }
    DB.set("diary", list);
    UI.closeModal();
    UI.floaty("📖");
    this.render();
  },
  edit(id) {
    const e = DB.get("diary", []).find((x) => x.id === id);
    if (e) this.compose(e);
  },
  del(id) {
    if (!confirm("Delete this entry?")) return;
    DB.set("diary", DB.get("diary", []).filter((e) => e.id !== id));
    this.render();
  },
  memoryLane() {
    const list = DB.get("diary", []);
    if (!list.length) { UI.toast("No memories yet 💭"); return; }
    const e = list[Math.floor(Math.random() * list.length)];
    const p = PEOPLE[e.author];
    UI.modal(`<div class="center"><div style="font-size:30px">🎲</div>
      <div class="muted" style="font-size:12px;margin:4px 0 14px">Memory Lane</div></div>
      <div class="diary-entry ${p.cls}" style="margin:0">
        <div class="d">${p.emoji} ${p.name} · ${fmtDate(e.date)}</div>
        ${e.title ? `<h3>${UI.esc(e.title)}</h3>` : ""}
        <div class="txt">${UI.esc(e.text)}</div>
      </div>
      <button class="btn primary block mt" onclick="Diary.memoryLane()">🎲 Another memory</button>
      <button class="btn ghost block mt-s" onclick="UI.closeModal()">Close</button>`);
  },
  exportPdf() {
    const list = DB.get("diary", []).sort((a, b) => a.date - b.date);
    if (!list.length) { UI.toast("Nothing to export yet 📄"); return; }
    const w = window.open("", "_blank");
    const body = list.map((e) => `
      <div style="page-break-inside:avoid;margin-bottom:26px;border-left:4px solid ${e.author==="sophie"?"#C8B8E8":"#D4A5A5"};padding-left:14px">
        <div style="font-size:12px;color:#999">${PEOPLE[e.author].name} · ${fmtDate(e.date)}</div>
        ${e.title ? `<h2 style="margin:4px 0;font-family:Nunito">${e.title}</h2>` : ""}
        <div style="white-space:pre-wrap;color:#333">${UI.esc(e.text)}</div>
      </div>`).join("");
    w.document.write(`<html><head><title>Our Corner — Diary</title>
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800&family=Open+Sans&display=swap" rel="stylesheet">
      <style>body{font-family:'Open Sans';max-width:640px;margin:40px auto;padding:0 20px}h1{font-family:Nunito;color:#b9807f;text-align:center}</style></head>
      <body><h1>Luke &amp; Sophie 💖<br><small style="font-size:14px;color:#999">Our Corner — Couple Diary</small></h1>${body}
      <script>window.onload=()=>setTimeout(()=>window.print(),400)<\/script></body></html>`);
    w.document.close();
  },
};
