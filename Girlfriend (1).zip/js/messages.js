/* ============================================================
   messages.js — warm chat
   ============================================================ */

const Messages = {
  search: "",
  render() {
    const el = document.getElementById("messages");
    el.innerHTML = `
      ${UI.topbar("Messages", "💌 little notes back & forth")}
      <div class="search-bar">
        <span>🔍</span>
        <input id="msgSearch" placeholder="Search messages…" value="${UI.esc(this.search)}" oninput="Messages.onSearch(this.value)" />
      </div>
      <div class="row between" style="margin-bottom:10px">
        <div class="who-toggle" id="msgWho">
          <button class="luke ${App.who==="luke"?"on":""}" onclick="Messages.setWho('luke')">🦂 Luke</button>
          <button class="sophie ${App.who==="sophie"?"on":""}" onclick="Messages.setWho('sophie')">🌸 Sophie</button>
        </div>
        <span class="muted" style="font-size:11px">sending as ${PEOPLE[App.who].name}</span>
      </div>
      <div class="msg-wrap" id="msgList">${this.list()}</div>
      <div class="compose">
        <button class="icon-btn rec" id="recBtn" onclick="Messages.toggleRec()">🎙️</button>
        <button class="icon-btn" onclick="Messages.attach()">📷</button>
        <div class="field"><textarea id="msgInput" rows="1" placeholder="Write something sweet…" oninput="Messages.grow(this)"></textarea></div>
        <button class="icon-btn send heartbeat" onclick="Messages.send()">➤</button>
      </div>`;
    this.scrollBottom();
  },

  list() {
    let msgs = DB.get("messages", []);
    if (this.search) {
      const q = this.search.toLowerCase();
      msgs = msgs.filter((m) => (m.text || "").toLowerCase().includes(q));
    }
    const pinned = msgs.filter((m) => m.pinned);
    let html = "";
    if (pinned.length && !this.search) {
      html += `<div class="muted" style="font-size:11px;font-weight:700;margin-bottom:4px">📌 Pinned</div>`;
      html += pinned.map((m) => this.bubble(m)).join("");
      html += `<div style="height:1px;background:var(--line);margin:10px 0"></div>`;
    }
    if (!msgs.length) return UI.empty("💌", "No messages yet — say hi!");
    html += msgs.map((m) => this.bubble(m)).join("");
    return html;
  },

  bubble(m) {
    const p = PEOPLE[m.who];
    const me = m.who === App.who;
    return `<div class="bubble-row ${me ? "me" : ""}">
      <div class="avatar ${p.cls}">${p.emoji}</div>
      <div class="bubble ${p.cls}" ondblclick="Messages.pin('${m.id}')">
        ${m.pinned ? `<span class="pin">📌</span>` : ""}
        <div class="nm">${p.name}</div>
        ${m.text ? `<div>${UI.esc(m.text)}</div>` : ""}
        ${m.img ? `<img src="${m.img}" style="max-width:200px" />` : ""}
        ${m.audio ? `<audio controls src="${m.audio}"></audio>` : ""}
        <div class="tm">${relTime(m.ts)} ${m.pinned ? "" : "· dbl-tap to pin"}</div>
      </div>
    </div>`;
  },

  setWho(w) { App.setWho(w); this.render(); Home && (Home._dirty = true); },
  onSearch(v) { this.search = v; document.getElementById("msgList").innerHTML = this.list(); },

  grow(t) { t.style.height = "auto"; t.style.height = Math.min(120, t.scrollHeight) + "px"; },

  send() {
    const input = document.getElementById("msgInput");
    const text = input.value.trim();
    if (!text) return;
    this.push({ text });
    input.value = ""; input.style.height = "auto";
  },
  async attach() {
    const img = await UI.pickImage();
    if (img) this.push({ img });
  },
  push(payload) {
    const msgs = DB.get("messages", []);
    msgs.push({ id: uid(), who: App.who, ts: Date.now(), pinned: false, ...payload });
    DB.set("messages", msgs);
    logActivity("💌", `${PEOPLE[App.who].name} sent a message`);
    Coins.add(1);
    this.refresh();
  },
  pin(id) {
    const msgs = DB.get("messages", []);
    const m = msgs.find((x) => x.id === id);
    if (m) { m.pinned = !m.pinned; DB.set("messages", msgs); UI.floaty("📌"); this.refresh(); }
  },
  refresh() {
    document.getElementById("msgList").innerHTML = this.list();
    this.scrollBottom();
  },
  scrollBottom() {
    const list = document.getElementById("msgList");
    if (list && !this.search) list.scrollTop = list.scrollHeight;
    requestAnimationFrame(() => window.scrollTo(0, document.body.scrollHeight));
  },

  /* ---------- voice notes ---------- */
  async toggleRec() {
    const btn = document.getElementById("recBtn");
    if (this._rec) {
      this._rec.stop();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      const chunks = [];
      rec.ondataavailable = (e) => chunks.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: "audio/webm" });
        const reader = new FileReader();
        reader.onload = () => this.push({ audio: reader.result });
        reader.readAsDataURL(blob);
        btn.classList.remove("on");
        this._rec = null;
      };
      rec.start();
      this._rec = rec;
      btn.classList.add("on");
      UI.toast("Recording… tap 🎙️ to stop");
    } catch (e) {
      UI.toast("Mic not available 🎙️");
    }
  },
};
