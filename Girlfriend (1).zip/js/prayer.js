/* ============================================================
   prayer.js — prayer tracker + scripture of the day
   ============================================================ */

const SCRIPTURES = [
  { v: "Love is patient, love is kind. It does not envy, it does not boast, it is not proud.", r: "1 Corinthians 13:4" },
  { v: "Above all, love each other deeply, because love covers over a multitude of sins.", r: "1 Peter 4:8" },
  { v: "Two are better than one… If either of them falls down, one can help the other up.", r: "Ecclesiastes 4:9-10" },
  { v: "And now these three remain: faith, hope and love. But the greatest of these is love.", r: "1 Corinthians 13:13" },
  { v: "Be completely humble and gentle; be patient, bearing with one another in love.", r: "Ephesians 4:2" },
  { v: "Many waters cannot quench love; rivers cannot sweep it away.", r: "Song of Songs 8:7" },
  { v: "Let all that you do be done in love.", r: "1 Corinthians 16:14" },
  { v: "I have found the one whom my soul loves.", r: "Song of Songs 3:4" },
  { v: "He who finds a wife finds a good thing, and obtains favor from the Lord.", r: "Proverbs 18:22" },
  { v: "Hatred stirs up conflict, but love covers over all wrongs.", r: "Proverbs 10:12" },
  { v: "Trust in the Lord with all your heart and lean not on your own understanding.", r: "Proverbs 3:5" },
  { v: "Cast all your anxiety on him because he cares for you.", r: "1 Peter 5:7" },
  { v: "The Lord watch between you and me when we are away from each other.", r: "Genesis 31:49" },
  { v: "Love never fails.", r: "1 Corinthians 13:8" },
];

const Prayer = {
  todayScripture() {
    const idx = Math.floor(Date.now() / 86400000) % SCRIPTURES.length;
    return SCRIPTURES[idx];
  },
  render() {
    const el = document.getElementById("prayer");
    const s = this.todayScripture();
    const prayers = DB.get("prayers", []);
    const streak = Streaks.one("pray");
    const prayedToday = Streaks.isDoneToday("pray");
    el.innerHTML = `
      ${UI.topbar("Prayer", "🙏 growing together in faith")}
      <div class="scripture">
        <div class="muted" style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--sage-deep)">📖 Scripture of the day</div>
        <div class="verse mt-s">“${s.v}”</div>
        <div class="ref">— ${s.r}</div>
      </div>

      <div class="card mt" style="display:flex;align-items:center;gap:12px">
        <div style="font-size:30px">🙏</div>
        <div class="grow">
          <div style="font-weight:800">Prayed together today?</div>
          <div class="muted" style="font-size:12px">${streak.count}-day streak 🔥</div>
        </div>
        <button class="chk ${prayedToday?"done":""}" style="width:40px;height:40px" onclick="Prayer.prayedToday(event)">${prayedToday?"✓":""}</button>
      </div>

      <div class="section-label">🕊️ Prayer wall <span class="more" onclick="Prayer.add()">＋ add request</span></div>
      <div id="prayerWall">
        ${prayers.length ? prayers.map((p) => this.item(p)).join("") : UI.empty("🕊️", "Add a prayer request to your wall")}
      </div>`;
  },
  item(p) {
    return `<div class="prayer-item ${p.answered?"answered":""}">
      <button class="box" onclick="Prayer.toggle('${p.id}')">${p.answered?"✓":""}</button>
      <div class="grow">
        <div class="pt">${UI.esc(p.text)}</div>
        <div class="pm">${PEOPLE[p.who]?PEOPLE[p.who].emoji+" ":""}${relTime(p.ts)}${p.answered?" · answered 🙌":""}</div>
      </div>
      <button class="btn sm ghost" onclick="Prayer.del('${p.id}')">✕</button>
    </div>`;
  },
  prayedToday(ev) {
    if (Streaks.isDoneToday("pray")) { UI.toast("Already prayed today 🙏"); return; }
    const s = Streaks.did("pray");
    UI.floaty("🙏", ev);
    if (s.count % 7 === 0) UI.confetti(50);
    logActivity("🙏", `You prayed together (${s.count}🔥)`);
    this.render();
  },
  add() {
    UI.modal(`<h3>New prayer request 🕊️</h3>
      <div class="field-group"><label>What are we praying for?</label>
        <textarea id="prReq" rows="3" placeholder="A request, a worry, a hope…"></textarea></div>
      <button class="btn primary block" onclick="Prayer.save()">Add to wall</button>`);
  },
  save() {
    const text = document.getElementById("prReq").value.trim();
    if (!text) { UI.toast("Type your request 💭"); return; }
    const list = DB.get("prayers", []);
    list.unshift({ id: uid(), text, who: App.who, ts: Date.now(), answered: false });
    DB.set("prayers", list);
    UI.closeModal(); this.render();
  },
  toggle(id) {
    const list = DB.get("prayers", []); const p = list.find((x) => x.id === id);
    p.answered = !p.answered; DB.set("prayers", list);
    if (p.answered) { UI.floaty("🙌"); UI.toast("Praise! Prayer answered 🙌"); logActivity("🙌", "A prayer was answered!"); }
    this.render();
  },
  del(id) {
    DB.set("prayers", DB.get("prayers", []).filter((x) => x.id !== id));
    this.render();
  },
};
