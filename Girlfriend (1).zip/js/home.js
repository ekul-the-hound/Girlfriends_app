/* ============================================================
   home.js — dashboard
   ============================================================ */

const Home = {
  render() {
    const el = document.getElementById("home");
    const now = new Date();
    const hr = now.getHours();
    let greet = "Good evening", gEmoji = "🌙";
    if (hr < 12) { greet = "Good morning"; gEmoji = "☀️"; }
    else if (hr < 18) { greet = "Good afternoon"; gEmoji = "🌤️"; }

    el.innerHTML = `
      <div class="hero">
        <div class="greet">
          <div class="hi">${greet} ${gEmoji}</div>
          <h1>Luke <span class="amp">&amp;</span> Sophie</h1>
          <div class="date">${now.toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"})}</div>
        </div>
        ${this.potd()}
      </div>

      <div class="section-label">How are we feeling?</div>
      ${this.moods()}

      <div class="section-label">Counting down ⏳ <span class="more" onclick="Home.tickNow()"></span></div>
      ${this.countdowns()}

      <div class="section-label">Daily rhythms 🔥</div>
      <div class="card">${this.streaks()}</div>

      <div class="section-label">Jump in</div>
      ${this.quickActions()}

      <div class="section-label">Lately</div>
      <div class="card flat">${this.activity()}</div>

      <div class="center mt" style="padding:8px 0 4px">
        <button class="chip lav heartbeat" onclick="UI.go('stats')">💖 See our stats</button>
        <button class="chip sage heartbeat" onclick="UI.go('settings')">⚙️ Settings</button>
      </div>
    `;
    this.startTick();
  },

  /* ---------- photo of the day ---------- */
  potd() {
    const p = DB.get("photoOfDay", null);
    const inner = p && p.img
      ? `<img src="${p.img}" alt="Photo of the day" />`
      : `<span class="empty">＋</span>`;
    return `<div class="potd">
      <div class="lbl">📸 Photo of the Day</div>
      <button class="frame" onclick="Home.potdTap()">${inner}</button>
      <div class="cap">${p && p.caption ? UI.esc(p.caption) : (p && p.img ? "" : "tap to add")}</div>
    </div>`;
  },
  async potdTap() {
    const p = DB.get("photoOfDay", null);
    if (p && p.img) { Gallery.openLightboxFor(p.img, p.caption || "Photo of the Day"); return; }
    const img = await UI.pickImage();
    if (!img) return;
    const caption = prompt("Add a caption (optional):", "") || "";
    DB.set("photoOfDay", { img, caption, date: todayKey() });
    // also drop into gallery
    const photos = DB.get("photos", []);
    photos.unshift({ id: uid(), img, caption, ts: Date.now(), fav: false });
    DB.set("photos", photos);
    Streaks.did("photo");
    logActivity("📸", `${PEOPLE[App.who].name} set the Photo of the Day`);
    UI.floaty("💖");
    this.render();
  },

  /* ---------- moods ---------- */
  moods() {
    const state = DB.get("moods", { luke: null, sophie: null, date: todayKey() });
    if (state.date !== todayKey()) { /* keep yesterday visible but allow update */ }
    const mine = state[App.who];
    const chips = MOODS.map(([emoji, name]) => `
      <button class="mood ${mine === name ? "active" : ""}" onclick="Home.setMood('${name}','${emoji}')">
        <div class="bubble">${emoji}</div>
        <div class="name">${name}</div>
      </button>`).join("");

    const lukeM = state.luke ? moodByName(state.luke) : null;
    const sopM = state.sophie ? moodByName(state.sophie) : null;
    let match = "";
    if (state.luke && state.sophie) {
      match = state.luke === state.sophie
        ? `💞 You're both feeling <b>${state.luke}</b> — totally in sync!`
        : `Luke feels ${lukeM[0]} and Sophie feels ${sopM[0]} — send some love 💌`;
    } else if (state.luke || state.sophie) {
      match = "Waiting for the other to check in… 🫶";
    }

    return `
      <div class="mood-scroll">${chips}</div>
      <div class="mood-status">
        <div class="who"><div class="top">🦂 Luke</div><div class="val">${lukeM ? lukeM[0] + " " + state.luke : "—"}</div></div>
        <div class="who"><div class="top">🌸 Sophie</div><div class="val">${sopM ? sopM[0] + " " + state.sophie : "—"}</div></div>
      </div>
      ${match ? `<div class="mood-match">${match}</div>` : ""}`;
  },
  setMood(name, emoji) {
    const state = DB.get("moods", { luke: null, sophie: null, date: todayKey() });
    if (state.date !== todayKey()) { state.luke = null; state.sophie = null; state.date = todayKey(); }
    state[App.who] = name;
    DB.set("moods", state);
    // mood history for stats
    const hist = DB.get("moodHistory", []);
    hist.push({ who: App.who, mood: name, ts: Date.now() });
    DB.set("moodHistory", hist.slice(-200));
    logActivity(emoji, `${PEOPLE[App.who].name} feels ${name}`);
    UI.floaty("💗");
    Pet.syncMood && Pet.syncMood();
    this.render();
  },

  /* ---------- countdowns ---------- */
  countdowns() {
    const list = DB.get("countdowns", []);
    const cards = list.map((c) => {
      const diff = c.date - Date.now();
      const passed = diff < 0;
      const abs = Math.abs(diff);
      const d = Math.floor(abs / 86400000);
      const h = Math.floor((abs % 86400000) / 3600000);
      const m = Math.floor((abs % 3600000) / 60000);
      return `<div class="cd-card ${passed ? "passed" : ""}" data-cd="${c.id}">
        <button class="del" onclick="Home.delCountdown('${c.id}')">✕</button>
        <div class="ttl">${UI.esc(c.title)}</div>
        <div class="when">${passed ? "since " : ""}${new Date(c.date).toLocaleDateString(undefined,{month:"short",day:"numeric"})}</div>
        <div class="nums">
          <div class="unit"><b class="cd-d">${d}</b><span>days</span></div>
          <div class="unit"><b class="cd-h">${h}</b><span>hrs</span></div>
          <div class="unit"><b class="cd-m">${m}</b><span>min</span></div>
        </div>
      </div>`;
    }).join("");
    return `<div class="cd-scroll">
      ${cards}
      <button class="cd-add" onclick="Home.addCountdown()">＋</button>
    </div>`;
  },
  addCountdown() {
    const def = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 16);
    UI.modal(`
      <h3>New countdown ⏳</h3>
      <div class="field-group"><label>What are we waiting for?</label>
        <input id="cdTitle" placeholder="e.g. Sophie visits!" /></div>
      <div class="field-group"><label>When?</label>
        <input id="cdDate" type="datetime-local" value="${def}" /></div>
      <button class="btn primary block" onclick="Home.saveCountdown()">Add countdown</button>
    `);
  },
  saveCountdown() {
    const title = document.getElementById("cdTitle").value.trim();
    const date = document.getElementById("cdDate").value;
    if (!title || !date) { UI.toast("Give it a name and a date 💕"); return; }
    const list = DB.get("countdowns", []);
    list.push({ id: uid(), title, date: new Date(date).getTime() });
    DB.set("countdowns", list);
    UI.closeModal();
    this.render();
  },
  delCountdown(id) {
    DB.set("countdowns", DB.get("countdowns", []).filter((c) => c.id !== id));
    this.render();
  },

  /* live ticking */
  startTick() {
    clearInterval(this._tick);
    this._tick = setInterval(() => { if (App.current === "home") this.tick(); }, 1000 * 30);
  },
  tick() {
    document.querySelectorAll("#home .cd-card").forEach((card) => {
      const id = card.dataset.cd;
      const c = DB.get("countdowns", []).find((x) => x.id === id);
      if (!c) return;
      const abs = Math.abs(c.date - Date.now());
      card.querySelector(".cd-d").textContent = Math.floor(abs / 86400000);
      card.querySelector(".cd-h").textContent = Math.floor((abs % 86400000) / 3600000);
      card.querySelector(".cd-m").textContent = Math.floor((abs % 3600000) / 60000);
    });
  },
  tickNow() { this.tick(); },

  /* ---------- streaks ---------- */
  streaks() {
    return STREAK_DEFS.map((def) => {
      const s = Streaks.one(def.key);
      const done = Streaks.isDoneToday(def.key);
      const pct = Math.min(100, (s.count / 7) * 100);
      return `<div class="streak">
        <div class="ic">${def.icon}</div>
        <div class="body" onclick="Home.streakHistory('${def.key}')">
          <div class="nm">${def.name}</div>
          <div class="bar"><i style="width:${pct}%"></i></div>
        </div>
        <div class="cnt">${s.count}🔥</div>
        <button class="chk ${done ? "done" : ""}" onclick="Home.markStreak('${def.key}', event)">${done ? "✓" : ""}</button>
      </div>`;
    }).join("");
  },
  markStreak(key, ev) {
    if (Streaks.isDoneToday(key)) { UI.toast("Already done today 💫"); return; }
    const s = Streaks.did(key);
    UI.floaty("🔥", ev);
    if (s.count > 0 && s.count % 7 === 0) { UI.confetti(); UI.toast(`${s.count}-day streak! 🎉`); }
    const def = STREAK_DEFS.find((d) => d.key === key);
    logActivity(def.icon, `${PEOPLE[App.who].name} kept the ${def.name} streak (${s.count}🔥)`);
    this.render();
  },
  streakHistory(key) {
    const s = Streaks.one(key);
    const def = STREAK_DEFS.find((d) => d.key === key);
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const dk = todayKey(new Date(Date.now() - i * 86400000));
      const hit = (s.history || []).includes(dk);
      days.push(`<div style="text-align:center;flex:1">
        <div style="width:30px;height:30px;margin:0 auto;border-radius:9px;display:grid;place-items:center;font-size:14px;background:${hit ? "var(--sage)" : "var(--bg-tint)"};color:${hit ? "#fff" : "var(--ink-faint)"}">${hit ? "✓" : ""}</div>
        <div style="font-size:9px;color:var(--ink-faint);margin-top:3px">${new Date(Date.now() - i * 86400000).getDate()}</div>
      </div>`);
    }
    UI.modal(`<h3>${def.icon} ${def.name}</h3>
      <div class="muted" style="font-size:13px;margin-bottom:12px">Current streak: <b>${s.count} days</b> · last 2 weeks</div>
      <div style="display:flex;gap:3px">${days.join("")}</div>
      <button class="btn ghost block mt" onclick="UI.closeModal()">Close</button>`);
  },

  /* ---------- quick actions ---------- */
  quickActions() {
    const items = [
      ["💌", "Messages", "messages"],
      ["📖", "Couple Diary", "diary"],
      ["❓", "Daily Q's", "questions"],
      ["🎮", "Play Games", "games"],
      ["🐶", "Our Puppy", "pet"],
      ["💡", "Date Ideas", "dates"],
      ["🖼️", "Gallery", "gallery"],
      ["🙏", "Prayer", "prayer"],
      ["🎨", "Draw", "__draw"],
    ];
    return `<div class="qa-grid">${items.map(([ic, lbl, go]) => `
      <button class="qa" onclick="${go === "__draw" ? "Games.draw('Sophie')" : `UI.go('${go}',{slide:true})`}">
        <div class="ic">${ic}</div><div class="lbl">${lbl}</div>
      </button>`).join("")}</div>`;
  },

  /* ---------- activity feed ---------- */
  activity() {
    const feed = DB.get("activity", []).slice(0, 6);
    if (!feed.length) return UI.empty("🌱", "Your story starts here. Do something together!");
    return feed.map((a) => `<div class="feed-item">
      <div class="dot">${a.emoji}</div>
      <div class="txt">${UI.esc(a.text)}<div class="t">${relTime(a.ts)}</div></div>
    </div>`).join("");
  },
};
