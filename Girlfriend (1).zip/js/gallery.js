/* ============================================================
   gallery.js — shared photo album + lightbox
   ============================================================ */

const Gallery = {
  lbList: [], lbIndex: 0,

  render() {
    const el = document.getElementById("gallery");
    const photos = DB.get("photos", []);
    const potd = DB.get("photoOfDay", null);
    el.innerHTML = `
      ${UI.topbar("Photo Gallery", `🖼️ ${photos.length} memories`)}
      ${potd && potd.img ? `
        <div class="section-label">📸 Photo of the day</div>
        <div class="card" style="padding:8px">
          <img src="${potd.img}" style="width:100%;border-radius:12px;max-height:220px;object-fit:cover" onclick="Gallery.openLightboxFor('${potd.img}','${UI.esc(potd.caption||"Photo of the Day")}')" />
          ${potd.caption ? `<div class="center muted" style="font-size:12px;margin-top:6px">${UI.esc(potd.caption)}</div>` : ""}
        </div>` : ""}
      <div class="section-label">All photos <span class="more" onclick="Gallery.downloadAll()">⬇️ Download all</span></div>
      <div class="gal-grid">
        <button class="gal-add" onclick="Gallery.upload()">＋</button>
        ${photos.map((p, i) => `<div class="gal-cell" onclick="Gallery.openLightbox(${i})">
          <img src="${p.img}" />
          ${p.fav ? `<span class="fav">❤️</span>` : ""}
        </div>`).join("")}
      </div>
      ${!photos.length ? UI.empty("🖼️", "Add your first photo memory 💕") : ""}`;
  },

  async upload() {
    const img = await UI.pickImage();
    if (!img) return;
    const caption = prompt("Caption (optional):", "") || "";
    const photos = DB.get("photos", []);
    photos.unshift({ id: uid(), img, caption, ts: Date.now(), fav: false });
    DB.set("photos", photos);
    Streaks.did("photo");
    logActivity("📸", `${PEOPLE[App.who].name} added a photo`);
    Coins.add(1);
    this.render();
  },

  /* ---------- lightbox ---------- */
  openLightbox(index) {
    this.lbList = DB.get("photos", []);
    this.lbIndex = index;
    this.showLb();
    document.getElementById("lightbox").classList.add("on");
  },
  openLightboxFor(img, caption) {
    this.lbList = [{ img, caption, single: true }];
    this.lbIndex = 0;
    this.showLb();
    document.getElementById("lightbox").classList.add("on");
  },
  showLb() {
    const p = this.lbList[this.lbIndex];
    if (!p) { this.closeLb(); return; }
    document.getElementById("lbImg").src = p.img;
    document.getElementById("lbCap").textContent = p.caption || "";
    document.querySelector('[data-lb="fav"]').textContent = p.fav ? "❤️" : "🤍";
    const single = p.single;
    document.querySelectorAll(".lightbox .nav").forEach((n) => n.style.display = single ? "none" : "grid");
    document.querySelector('[data-lb="fav"]').style.display = single ? "none" : "grid";
    document.querySelector('[data-lb="del"]').style.display = single ? "none" : "grid";
  },
  lbNav(dir) {
    if (this.lbList[this.lbIndex] && this.lbList[this.lbIndex].single) return;
    this.lbIndex = (this.lbIndex + dir + this.lbList.length) % this.lbList.length;
    this.showLb();
  },
  lbFav() {
    const p = this.lbList[this.lbIndex];
    if (!p || p.single) return;
    const photos = DB.get("photos", []);
    const real = photos.find((x) => x.id === p.id);
    if (real) { real.fav = !real.fav; p.fav = real.fav; DB.set("photos", photos); this.showLb(); UI.floaty(real.fav ? "❤️" : "🤍"); }
  },
  lbDel() {
    const p = this.lbList[this.lbIndex];
    if (!p || p.single) return;
    if (!confirm("Delete this photo?")) return;
    DB.set("photos", DB.get("photos", []).filter((x) => x.id !== p.id));
    this.closeLb();
    this.render();
  },
  closeLb() { document.getElementById("lightbox").classList.remove("on"); },

  downloadAll() {
    const photos = DB.get("photos", []);
    if (!photos.length) { UI.toast("No photos yet 🖼️"); return; }
    photos.forEach((p, i) => {
      const a = document.createElement("a");
      a.href = p.img; a.download = `our-corner-${i + 1}.jpg`;
      document.body.appendChild(a); a.click(); a.remove();
    });
    UI.toast(`Downloading ${photos.length} photos ⬇️`);
  },
};
