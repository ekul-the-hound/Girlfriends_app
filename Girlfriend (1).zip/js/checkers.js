/* ============================================================
   checkers.js — turn-based checkers, saved + undo + confetti
   Luke 🦂 (bottom, moves up) vs Sophie 🌸 (top, moves down)
   ============================================================ */

const Checkers = {
  fresh() {
    const b = Array.from({ length: 8 }, () => Array(8).fill(null));
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 1) {
        if (r < 3) b[r][c] = { who: "sophie", king: false };
        else if (r > 4) b[r][c] = { who: "luke", king: false };
      }
    }
    return { board: b, turn: "luke", sel: null, history: [], winner: null };
  },
  load() {
    let s = DB.get("checkers", null);
    if (!s || !s.board) s = this.fresh();
    this.s = s;
    return s;
  },
  save() { DB.set("checkers", this.s); },

  render() {
    const s = this.s || this.load();
    const el = document.getElementById("game-checkers");
    const counts = this.counts();
    el.innerHTML = `
      ${UI.topbar("Checkers", "♟️ tap a piece, then a glowing square", "games")}
      <div class="checkers-wrap">
        <div class="row between" style="margin-bottom:12px">
          <span class="chip rose">🦂 ${counts.luke}</span>
          <span class="chip ${s.winner ? "sage" : (s.turn==="luke"?"rose":"lav")}" style="font-weight:800">
            ${s.winner ? `${PEOPLE[s.winner].emoji} ${PEOPLE[s.winner].name} wins!` : `${PEOPLE[s.turn].name}'s turn`}</span>
          <span class="chip lav">🌸 ${counts.sophie}</span>
        </div>
        <div class="board" id="board">${this.squares()}</div>
        <div class="row" style="gap:8px;margin-top:14px">
          <button class="btn ghost grow" onclick="Checkers.undo()">↩️ Undo</button>
          <button class="btn ghost grow" onclick="Checkers.reset()">🔄 New game</button>
        </div>
      </div>`;
  },

  counts() {
    let luke = 0, sophie = 0;
    this.s.board.forEach((row) => row.forEach((p) => { if (p) p.who === "luke" ? luke++ : sophie++; }));
    return { luke, sophie };
  },

  squares() {
    const s = this.s;
    const targets = s.sel ? this.movesFor(s.sel.r, s.sel.c).map((m) => m.r + "-" + m.c) : [];
    let html = "";
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      const dark = (r + c) % 2 === 1;
      const p = s.board[r][c];
      const isSel = s.sel && s.sel.r === r && s.sel.c === c;
      const isTarget = targets.includes(r + "-" + c);
      html += `<div class="sq ${dark ? "dark" : "light"} ${isSel ? "sel" : ""} ${isTarget ? "target" : ""}" onclick="Checkers.tap(${r},${c})">
        ${p ? `<div class="pc ${p.who} ${p.king ? "king" : ""}">${p.who === "luke" ? "🦂" : "🌸"}</div>` : ""}
      </div>`;
    }
    return html;
  },

  /* valid simple + jump moves for a piece */
  movesFor(r, c) {
    const s = this.s, p = s.board[r][c];
    if (!p) return [];
    const dirs = p.king ? [[-1,-1],[-1,1],[1,-1],[1,1]]
      : (p.who === "luke" ? [[-1,-1],[-1,1]] : [[1,-1],[1,1]]);
    const moves = [];
    const jumps = [];
    for (const [dr, dc] of dirs) {
      const nr = r + dr, nc = c + dc;
      if (this.inB(nr, nc) && !s.board[nr][nc]) moves.push({ r: nr, c: nc });
      const jr = r + dr * 2, jc = c + dc * 2;
      if (this.inB(jr, jc) && !s.board[jr][jc] && s.board[nr] && s.board[nr][nc] && s.board[nr][nc].who !== p.who)
        jumps.push({ r: jr, c: jc, cap: { r: nr, c: nc } });
    }
    // if any jump exists for this piece, prefer jumps
    return jumps.length ? jumps : moves;
  },
  inB(r, c) { return r >= 0 && r < 8 && c >= 0 && c < 8; },

  hasAnyJump(who) {
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      const p = this.s.board[r][c];
      if (p && p.who === who && this.movesFor(r, c).some((m) => m.cap)) return true;
    }
    return false;
  },

  tap(r, c) {
    const s = this.s;
    if (s.winner) return;
    const p = s.board[r][c];
    if (s.sel) {
      const move = this.movesFor(s.sel.r, s.sel.c).find((m) => m.r === r && m.c === c);
      if (move) { this.doMove(s.sel.r, s.sel.c, move); return; }
    }
    if (p && p.who === s.turn) {
      // enforce capture priority: only allow selecting pieces with a jump if any jump exists
      if (this.hasAnyJump(s.turn) && !this.movesFor(r, c).some((m) => m.cap)) {
        UI.toast("There's a capture available! 🎯");
        return;
      }
      s.sel = { r, c };
    } else {
      s.sel = null;
    }
    this.render();
  },

  doMove(fr, fc, move) {
    const s = this.s;
    s.history.push(JSON.stringify({ board: s.board, turn: s.turn }));
    if (s.history.length > 20) s.history.shift();
    const p = s.board[fr][fc];
    s.board[fr][fc] = null;
    s.board[move.r][move.c] = p;
    let captured = false;
    if (move.cap) {
      s.board[move.cap.r][move.cap.c] = null;
      captured = true;
      UI.floaty("💥");
    }
    // king promotion
    if ((p.who === "luke" && move.r === 0) || (p.who === "sophie" && move.r === 7)) {
      if (!p.king) { p.king = true; UI.floaty("👑"); }
    }
    // multi-jump?
    if (captured && this.movesFor(move.r, move.c).some((m) => m.cap)) {
      s.sel = { r: move.r, c: move.c };
      this.save(); this.render();
      return;
    }
    s.sel = null;
    s.turn = s.turn === "luke" ? "sophie" : "luke";
    this.checkWin();
    this.save();
    this.render();
  },

  checkWin() {
    const s = this.s;
    const counts = this.counts();
    if (counts.luke === 0) s.winner = "sophie";
    else if (counts.sophie === 0) s.winner = "luke";
    else {
      // no legal moves for player to move
      let canMove = false;
      for (let r = 0; r < 8 && !canMove; r++) for (let c = 0; c < 8; c++) {
        const p = s.board[r][c];
        if (p && p.who === s.turn && this.movesFor(r, c).length) { canMove = true; break; }
      }
      if (!canMove) s.winner = s.turn === "luke" ? "sophie" : "luke";
    }
    if (s.winner) {
      setTimeout(() => { UI.confetti(120); UI.toast(`${PEOPLE[s.winner].emoji} ${PEOPLE[s.winner].name} wins! 🎉`); }, 200);
      Coins.add(6);
      logActivity("♟️", `${PEOPLE[s.winner].name} won a game of checkers`);
    }
  },

  undo() {
    const s = this.s;
    if (!s.history.length) { UI.toast("Nothing to undo"); return; }
    const prev = JSON.parse(s.history.pop());
    s.board = prev.board; s.turn = prev.turn; s.sel = null; s.winner = null;
    this.save(); this.render();
  },
  reset() {
    if (!confirm("Start a new game?")) return;
    this.s = this.fresh(); this.save(); this.render();
  },
};
