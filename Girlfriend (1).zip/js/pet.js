/* ============================================================
   pet.js — Our Puppy (gacha pet)
   ============================================================ */

const PET_FORMS = { puppy: "🐶", adult: "🐕", golden: "🦮" };
const ACCESSORIES = [
  { id: "bow",    emoji: "🎀", name: "Bow",      cost: 10, pos: "top:6px" },
  { id: "tophat", emoji: "🎩", name: "Top Hat",  cost: 15, pos: "top:0" },
  { id: "crown",  emoji: "👑", name: "Crown",    cost: 25, pos: "top:0" },
  { id: "collar", emoji: "🧣", name: "Scarf",    cost: 12, pos: "bottom:18px" },
  { id: "glasses",emoji: "🕶️", name: "Shades",   cost: 18, pos: "top:30px" },
  { id: "flower", emoji: "🌸", name: "Flower",   cost: 8,  pos: "top:8px;left:60%" },
];

const Pet = {
  data() {
    let p = DB.get("pet", null);
    if (!p) {
      p = { name: "Our Puppy", born: Date.now(), happiness: 70, cleanliness: 70, energy: 70, hunger: 60,
            owned: [], equipped: [], lastCare: {} };
      DB.set("pet", p);
    }
    return p;
  },
  save(p) { DB.set("pet", p); },

  ageDays() { return daysBetween(this.data().born, Date.now()); },
  form() { const d = this.ageDays(); return d >= 100 ? "golden" : d >= 30 ? "adult" : "puppy"; },

  /* natural decay since last open */
  decay() {
    const p = this.data();
    const last = p.lastTick || Date.now();
    const hrs = (Date.now() - last) / 3600000;
    if (hrs > 0.1) {
      p.hunger = Math.min(100, p.hunger + hrs * 2);
      p.energy = Math.max(0, p.energy - hrs * 1.5);
      p.cleanliness = Math.max(0, p.cleanliness - hrs * 1);
      p.happiness = Math.max(0, Math.min(100, p.happiness - hrs * 1 + (p.hunger < 40 ? 0 : 0)));
      p.lastTick = Date.now();
      this.save(p);
    }
  },

  render() {
    this.decay();
    const p = this.data();
    const el = document.getElementById("pet");
    const mood = p.happiness > 70 ? "😍" : p.happiness > 40 ? "🙂" : "🥺";
    el.innerHTML = `
      ${UI.topbar("Our Puppy", `🐾 ${this.form()} form · day ${this.ageDays()}`)}
      <div class="row between" style="margin-bottom:12px">
        <span class="coins">💗 ${Coins.get()} love coins</span>
        <button class="btn ghost sm" onclick="Pet.rename()">✏️ Name</button>
      </div>
      <div class="pet-room">
        <div class="pet-stage">
          <div class="puppy" id="puppy">${PET_FORMS[this.form()]}
            ${this.accLayer(p)}
          </div>
        </div>
        <div class="pet-name-tag">
          <div class="nm">${UI.esc(p.name)} ${mood}</div>
          <div class="collar">collar engraved · “L &amp; S” 💞</div>
        </div>
      </div>

      <div class="pet-bars">
        ${this.bar("😊 Happiness", p.happiness, "linear-gradient(90deg,#D4A5A5,#C8B8E8)")}
        ${this.bar("🛁 Clean", p.cleanliness, "linear-gradient(90deg,#9ec9e8,#C8B8E8)")}
        ${this.bar("⚡ Energy", p.energy, "linear-gradient(90deg,#F2C14E,#D4A5A5)")}
        ${this.bar("🍖 Hunger", 100 - p.hunger, "linear-gradient(90deg,#B8C5B6,#8aa087)")}
      </div>

      <div class="care-row">
        <button class="care-btn" onclick="Pet.care('feed',event)"><div class="ic">🍖</div><div class="l">Feed</div></button>
        <button class="care-btn" onclick="Pet.care('bathe',event)"><div class="ic">🛁</div><div class="l">Bathe</div></button>
        <button class="care-btn" onclick="Pet.care('play',event)"><div class="ic">🎾</div><div class="l">Play</div></button>
        <button class="care-btn" onclick="Pet.care('sleep',event)"><div class="ic">😴</div><div class="l">Sleep</div></button>
      </div>

      <div class="section-label">🎁 Gacha shop <span class="more">earn coins from streaks &amp; games</span></div>
      <div class="qa-grid" style="grid-template-columns:repeat(3,1fr)">
        ${ACCESSORIES.map((a) => {
          const owned = p.owned.includes(a.id), equipped = p.equipped.includes(a.id);
          return `<button class="gacha-item ${owned?"owned":""} ${equipped?"equipped":""}" onclick="Pet.gacha('${a.id}')">
            ${a.emoji}<span class="cost">${owned ? (equipped?"✓ on":"tap") : "💗"+a.cost}</span></button>`;
        }).join("")}
      </div>
      <div class="center muted mt" style="font-size:12px">
        Evolves at <b>30 days</b> → 🐕 and <b>100 days</b> → 🦮 golden form
      </div>`;
  },

  accLayer(p) {
    return p.equipped.map((id) => {
      const a = ACCESSORIES.find((x) => x.id === id);
      return a ? `<span class="pet-acc" style="${a.pos};left:${a.pos.includes("left")?"":"50%"};transform:translateX(-50%)">${a.emoji}</span>` : "";
    }).join("");
  },

  bar(label, val, grad) {
    val = Math.round(val);
    return `<div class="pet-bar">
      <div class="pl">${label}</div>
      <div class="track"><i style="width:${val}%;background:${grad}"></i></div>
      <div class="pct">${val}%</div>
    </div>`;
  },

  care(action, ev) {
    const p = this.data();
    const today = todayKey();
    const wag = () => { const el = document.getElementById("puppy"); if (el) { el.classList.remove("happy"); void el.offsetWidth; el.classList.add("happy"); } };
    switch (action) {
      case "feed": p.hunger = Math.max(0, p.hunger - 35); p.happiness = Math.min(100, p.happiness + 8); UI.floaty("🍖", ev); break;
      case "bathe": p.cleanliness = Math.min(100, p.cleanliness + 40); p.happiness = Math.min(100, p.happiness + 5); UI.floaty("🫧", ev); break;
      case "play": p.energy = Math.max(0, p.energy - 10); p.happiness = Math.min(100, p.happiness + 15); UI.floaty("🎾", ev); break;
      case "sleep": p.energy = Math.min(100, p.energy + 45); UI.floaty("💤", ev); break;
    }
    p.lastTick = Date.now();
    this.save(p);
    wag();
    // small coin reward, once per action per day-ish
    Coins.add(1);
    logActivity("🐾", `You ${action === "feed" ? "fed" : action + "ed"} ${p.name}`);
    this.refreshBars();
  },
  refreshBars() {
    const p = this.data();
    const bars = document.querySelectorAll("#pet .pet-bar");
    const vals = [p.happiness, p.cleanliness, p.energy, 100 - p.hunger];
    bars.forEach((b, i) => {
      b.querySelector("i").style.width = Math.round(vals[i]) + "%";
      b.querySelector(".pct").textContent = Math.round(vals[i]) + "%";
    });
  },

  gacha(id) {
    const p = this.data();
    const a = ACCESSORIES.find((x) => x.id === id);
    if (p.owned.includes(id)) {
      // toggle equip
      if (p.equipped.includes(id)) p.equipped = p.equipped.filter((x) => x !== id);
      else p.equipped.push(id);
      this.save(p); this.render();
      return;
    }
    if (!Coins.spend(a.cost)) { UI.toast(`Need ${a.cost} 💗 — play games to earn!`); return; }
    p.owned.push(id); p.equipped.push(id);
    this.save(p);
    UI.confetti(40);
    UI.toast(`${a.emoji} ${a.name} unlocked!`);
    this.render();
  },

  rename() {
    const p = this.data();
    const n = prompt("Name your puppy:", p.name);
    if (n && n.trim()) { p.name = n.trim(); this.save(p); this.render(); }
  },

  syncMood() {
    // dog happiness nudged by the couple's moods
    const m = DB.get("moods", {});
    const good = ["Happy","Amazing","Adoring","Romantic","Grateful","Cuddly","Playful","Energetic","Celebrate"];
    const p = this.data();
    let bump = 0;
    if (good.includes(m.luke)) bump += 4;
    if (good.includes(m.sophie)) bump += 4;
    if (bump) { p.happiness = Math.min(100, p.happiness + bump); this.save(p); }
  },
  refreshCoins() {
    const el = document.querySelector("#pet .coins");
    if (el) el.textContent = `💗 ${Coins.get()} love coins`;
  },
};
